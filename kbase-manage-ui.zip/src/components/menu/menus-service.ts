import { MenuTypeEnum } from "@/constants/enum/menu-type.enum";
import { KmMenu } from "@/model/KmMenu";
import { Crumb } from "@/model/Crumb";
import { RouteLocationNormalizedLoaded } from "vue-router";
class MenusService {
  menus: KmMenu[] = [
    {
      menuId: "database",
      menuName: "数据库管理",
      menuType: MenuTypeEnum.LINK.code,
      menuUrl: "/main/database",
      menuIcon: "el-icon-s-data",
      children: []
    },
    {
      menuId: "view",
      menuName: "视图管理",
      menuType: MenuTypeEnum.LINK.code,
      menuUrl: "/main/view",
      menuIcon: "el-icon-view",
      children: []
    },
    {
      menuId: "dictionary",
      menuName: "系统词典",
      menuType: MenuTypeEnum.LINK.code,
      menuUrl: "/main/dictionary",
      menuIcon: "el-icon-document",
      children: []
    },
    {
      menuId: "fieldtype",
      menuName: "数据类型",
      menuType: MenuTypeEnum.LINK.code,
      menuUrl: "/main/fieldtype",
      menuIcon: "el-icon-document",
      children: []
    },
    {
      menuId: "indextype",
      menuName: "索引类型",
      menuType: MenuTypeEnum.LINK.code,
      menuUrl: "/main/indextype",
      menuIcon: "el-icon-document",
      children: []
    },
    {
      menuId: "task",
      menuName: "任务管理",
      menuType: MenuTypeEnum.LINK.code,
      menuUrl: "/main/task",
      menuIcon: "el-icon-date",
      children: [
        {
          menuId: "taskPlan",
          menuName: "计划任务",
          menuType: MenuTypeEnum.LINK.code,
          menuUrl: "/main/task/task-plan",
          children: []
        },
        {
          menuId: "taskQueue",
          menuName: "任务队列",
          menuType: MenuTypeEnum.LINK.code,
          menuUrl: "/main/task/task-queue",
          children: []
        }
      ]
    },
    {
      menuId: "expand",
      menuName: "扩展管理",
      menuType: MenuTypeEnum.LINK.code,
      menuUrl: "/main/expand",
      menuIcon: "el-icon-s-promotion",
      children: []
    },
    {
      menuId: "cluster",
      menuName: "集群管理",
      menuType: MenuTypeEnum.LINK.code,
      menuUrl: "/main/cluster",
      menuIcon: "el-icon-s-grid",
      children: [
        {
          menuId: "node",
          menuName: "节点分布",
          menuType: MenuTypeEnum.LINK.code,
          menuUrl: "/main/cluster/node",
          children: []
        },
        {
          menuId: "table",
          menuName: "表分布",
          menuType: MenuTypeEnum.LINK.code,
          menuUrl: "/main/cluster/table",
          children: []
        }
      ]
    },
    {
      menuId: "system",
      menuName: "系统信息",
      menuType: MenuTypeEnum.LINK.code,
      menuUrl: "/main/system",
      menuIcon: "el-icon-s-tools",
      children: [
        {
          menuId: "params",
          menuName: "系统参数",
          menuType: MenuTypeEnum.LINK.code,
          menuUrl: "/main/system/params",
          children: []
        },
        {
          menuId: "logs",
          menuName: "系统日志",
          menuType: MenuTypeEnum.LINK.code,
          menuUrl: "/main/system/logs",
          children: []
        }
      ]
    },
    {
      menuId: "account",
      menuName: "账号管理",
      menuType: MenuTypeEnum.LINK.code,
      menuUrl: "/main/account",
      menuIcon: "el-icon-user",
      children: [
        {
          menuId: "group",
          menuName: "组",
          menuType: MenuTypeEnum.LINK.code,
          menuUrl: "/main/account/group",
          children: []
        },
        {
          menuId: "user",
          menuName: "用户",
          menuType: MenuTypeEnum.LINK.code,
          menuUrl: "/main/account/user",
          children: []
        },
        {
          menuId: "olUser",
          menuName: "在线用户",
          menuType: MenuTypeEnum.LINK.code,
          menuUrl: "/main/account/ol-user",
          children: []
        }
      ]
    },
    {
      menuId: "help",
      menuName: "帮助",
      menuType: MenuTypeEnum.LINK.code,
      menuUrl: "/main/help",
      menuIcon: "el-icon-help",
      children: [
        {
          menuId: "register",
          menuName: "注册",
          menuType: MenuTypeEnum.LINK.code,
          menuUrl: "/main/help/register",
          children: []
        }
      ]
    },
    {
      menuId: "test",
      menuName: "测试",
      menuType: MenuTypeEnum.LINK.code,
      menuUrl: "/main/test",
      menuIcon: "el-icon-s-tools",
      children: []
    }
  ];
  recursiveSearchByUrl(url: string, menus: KmMenu[]): KmMenu | undefined {
    let res: KmMenu | undefined;
    for (const e of menus) {
      if (e.menuUrl === url) {
        res = e;
      } else if (e.children.length > 0) {
        res = this.recursiveSearchByUrl(url, e.children);
      }
      if (res) break;
    }
    return res;
  }
  refreshCrumbs(route: RouteLocationNormalizedLoaded, crumbs: Crumb[]): string {
    const c = crumbs.find(c => c.path === route.fullPath);
    if (c) {
      c.params = route.params;
      return c.menuId;
    } else {
      let title: string = route.meta.name as string;
      let menuId: string = route.meta.menuId as string;
      if (!title) {
        const menu = this.recursiveSearchByUrl(route.fullPath, this.menus);
        if (menu) {
          title = menu.menuName;
          menuId = menu.menuId;
        }
      }
      if (title && menuId) {
        const c: Crumb = {
          menuId: menuId,
          name: title,
          path: route.fullPath,
          component: route.name as string,
          params: route.params
        };
        crumbs.push(c);
      }
      return menuId;
    }
  }
}

export const menusService = new MenusService();
