<template>
  <el-dialog v-model="show">
    <div class="km-flex">
      <div class="km-w-80">
        <fieldset>
          <legend>引入信息</legend>
          <div class="km-flex km-mt-15">
            <div class="km-w-80">
              <div class="km-flex km-ai-center">
                <span class="km-nowrap km-w-20">文件路径</span>
                <el-input placeholder="请输入文件路径" clearable :value="form.path"></el-input>
              </div>
            </div>
            <div class="km-ml-10">
              <el-button icon="el-icon-s-grid" @click="dialogVisible = true"></el-button>
            </div>
          </div>
          <el-checkbox class="km-mt-15" v-model="form.checked">引入指定目录所有对象</el-checkbox>
        </fieldset>
      </div>
      <div class="km-text-center km-pt-15">
        <el-button class="km-w-50" @click="onSubmit">确定</el-button>
        <el-button class="km-w-50 km-mt-20 km-mr-10" @click="cancle">取消</el-button>
      </div>
    </div>
    <p>
      说明：引入的对象信息必须在服务器端
    </p>

    <el-dialog :title="form.checked ? '在服务器上选择路径' : '在服务器上选择文件'" v-model="dialogVisible" width="30%" append-to-body>
      <div style="height: 200px;overflow-y: scroll;margin-bottom: 15px;">
        <el-tree ref="tree" :props="props" :load="loadNode" @node-click="handleNodeClick" lazy> </el-tree>
      </div>
      <div class="km-flex km-ai-center km-jc-center">
        <span class="km-nowrap km-w-20 km-mr-15">{{ form.checked ? "选定的目录名" : "文件名" }}</span>
        <el-input readonly :value="form.path"></el-input>
      </div>
      <div class="km-flex km-ai-center km-jc-center km-mt-15" v-show="!form.checked">
        <span class="km-nowrap km-w-20 km-mr-15">文件类型</span>
        <el-input readonly placeholder="系统词典文件(*.sysdict)"></el-input>
      </div>
      <div class="km-flex km-ai-center km-jc-center km-mt-15">
        <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
        <el-button @click="dialogVisible = false">取 消</el-button>
      </div>
    </el-dialog>
  </el-dialog>
</template>

<script lang="ts">
import { kmApi } from "@/constants/api/km-api";
import { Constants } from "@/constants/constants";
import { clientService } from "@/services/client-service";

export default {
  name: "FileDialog",
  props: {
    show: {
      type: Boolean,
      default() {
        return false;
      }
    }
  },
  data() {
    return {
      form: {
        path: "",
        checked: true,
        suffix: "sysdict"
      },
      dialogVisible: false,
      props: {
        label: "name"
        // isLeaf: function(data) {
        //   return data.bIsFile == 1;
        // },
        // isLeaf: (data) => data.bIsFile == 1
      },
      rootDir: [],
      // selectedPath: [],
      // selectedPath: '',
      // eslint-disable-next-line @typescript-eslint/camelcase
      node_r: undefined,
      // eslint-disable-next-line @typescript-eslint/camelcase
      resovle_r: undefined
    } as any;
  },
  watch: {
    "form.checked": {
      handler() {
        if (this.resovle_r) {
          console.log(this.node_r);
          this.node_r.childNodes = [];
          this.loadNode(this.node_r, this.resovle_r);
        }
      },
      deep: true
    } as any
  },
  mounted() {
    this.loadRootDir();
  },
  methods: {
    loadRootDir() {
      clientService.general(kmApi.sysManageApi.FS).then(res => {
        if (res.code === Constants.CODE.SUCCESS) {
          this.rootDir = res.data;
        }
      });
    },
    onSubmit() {
      // console.log("submit!");
      this.$emit("confirm", this.form);
    },
    cancle() {
      this.$emit("cancle", this.form);
    },
    handleNodeClick(data: any, node: any) {
      console.log(node);
      this.form.path = data.path;
      // this.selectedPath = this.selectedPath.slice(0, node.level);
      // this.selectedPath[node.level] = data.szName;
      // this.form.path = this.selectedPath.join('/');
      // console.log('node click:', this.selectedPath)
    },
    loadNode(node: any, resolve: any) {
      // console.log(node)
      if (node.level === 0) {
        // eslint-disable-next-line @typescript-eslint/camelcase
        this.node_r = node;
        // eslint-disable-next-line @typescript-eslint/camelcase
        this.resovle_r = resolve;
        return resolve(this.rootDir);
      }

      // let path = this.selectedPath.slice(0, node.level);
      // path[node.level] = node.data.szName;
      // console.log(path)

      clientService.general(kmApi.sysManageApi.FS, { path: node.data.path, d: this.form.checked ? 1 : 0, suffix: this.form.suffix }).then(res => {
        if (res.code === Constants.CODE.SUCCESS) {
          resolve(res.data);
        }
      });
    }
  } as any
} as any;
</script>

<style scoped></style>
