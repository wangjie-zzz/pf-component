<template>
  <div class="km-flex km-flex-column">
    <div class="km-flex km-top">
      <div class="km-top-logo">
        <img class="km-vertical-middle" src="@/assets/images/logo.gif" />
      </div>
      <div class="km-flex km-flex-1 km-ai-center km-white">
        <div class="km-flex-1">
          <el-button class="km-vertical-middle" type="text" @click="collapse = !collapse">
            <i class="km-fs-40 km-white" :class="collapse ? 'el-icon-s-unfold' : 'el-icon-s-fold'"></i>
          </el-button>
          <span class="km-ml-5">欢迎进入webx-manager</span>
        </div>
        <el-button class="km-h-50 km-mr-15" @click="logout">退出登录</el-button>
      </div>
    </div>
    <div class="km-content km-flex">
      <el-menu :class="{ 'km-content-menu': !collapse }" :default-active="activeMenuId" @open="handleOpen" @close="handleClose" :collapse="collapse">
        <km-menu :menu-list="menus" @menuClick="menuClick"></km-menu>
      </el-menu>
      <div class="km-flex-1 km-w-0">
        <el-tabs class="km-bgwhite" v-model="activeCrumb" :closable="closable" @tab-remove="tabRemove" @tab-click="tabClick">
          <el-tab-pane v-for="c in crumbs" :key="c.path" :label="c.name" :name="c.path"></el-tab-pane>
        </el-tabs>
        <slot></slot>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, Ref, computed, inject } from "vue";
import KmMenu from "@/components/menu/KmMenu.vue";
import { menusService } from "@/components/menu/menus-service.ts";
import { Crumb } from "@/model/Crumb";
import { useRouter } from "vue-router";
import { clientService } from "@/services/client-service";
import { kmApi } from "@/constants/api/km-api";
import { authService } from "@/services/auth-service";
import { ElMessageBox } from "element-plus";

export default defineComponent({
  name: "KmHeader",
  props: {},
  components: { KmMenu },
  setup() {
    const collapse: Ref<boolean> = ref(false);
    const router = useRouter();
    const crumbs: Crumb[] = inject("crumbs") || [];
    const activeCrumb = inject("activeCrumb");
    const activeMenuId = inject("activeMenuId");
    const closable = computed(() => {
      return crumbs.length > 1;
    });
    const tabClick = (e: any) => {
      const idx = crumbs.findIndex(c => c.path === e.paneName);
      if (e.paneName && idx !== -1) {
        /*
      path忽略params属性，params参数可匹配路径参数 或者 隐藏
      fullpath会包含query参数
      * */
        // this.$router.push({ path: e.paneName, params: this.crumbs[idx].params });
        router.push({ path: e.paneName });
      }
    };
    const tabRemove = (path: string) => {
      const idx = crumbs.findIndex(e => e.path === path);
      if (idx > -1) {
        crumbs.splice(idx, 1);
        if (path === activeCrumb) {
          tabClick({ paneName: crumbs[0].path });
        }
      }
    };
    const logout = () => {
      ElMessageBox.confirm("退出当前用户，是否确认？", { confirmButtonText: "确定", cancelButtonText: "取消", type: "warning" }).then(() => {
        /*点击确认*/
        clientService.general(kmApi.userApi.closeConnect).then(res => {
          authService.clearCache();
          window.location.reload();
        });
      });
    };
    return {
      menus: menusService.menus,
      collapse,
      activeMenuId,
      activeCrumb,
      crumbs,
      closable,
      tabClick,
      tabRemove,
      logout,
      menuClick(e: any) {
        router.push({ path: e.menuUrl });
      },
      handleOpen() {
        console.log("handleOpen");
      },
      handleClose() {
        console.log("handleClose");
      }
    };
  }
});
</script>

<style scoped lang="scss">
.#{$prefix} {
  &-top {
    height: 60px;
    line-height: 60px;
    background: #409eff;
    &-logo {
      min-width: 200px;
      max-width: 200px;
      text-align: center;
    }
  }
  &-content {
    height: calc(100vh - 60px);
    &-menu {
      overflow: auto;
      min-width: 200px;
    }
  }
}
</style>
