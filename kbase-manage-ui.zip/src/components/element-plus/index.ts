import { ElButton, ElMenuItem, ElSelect, ElTooltip, ElSubmenu, ElMenu, ElTabs, ElTabPane, ElTree, ElScrollbar, ElDropdownMenu, ElDropdownItem, ElDropdown, ElInput, ElOption, ElCheckbox, ElDatePicker, ElRadio, ElRadioGroup, ElTimePicker, ElCheckboxGroup, ElPopper, ElInputNumber, ElEmpty, ElPagination, ElTag, ElDialog, ElTransfer, ElSpace } from "element-plus";
import { App } from "vue";
import Form from "@/components/form/form.vue";
import ElTable from "@/components/table/table.vue";
import ElTableColumn from "@/components/table/table-column/index";

export function elInstall(app: App): App {
  app.config.globalProperties.$ELEMENT = { size: "small", zIndex: 3000 };

  app.component(Form.name, Form);
  app.component(ElTable.name, ElTable);
  app.component(ElTableColumn.name, ElTableColumn);
  return app
    .use(ElMenu)
    .use(ElSubmenu)
    .use(ElMenuItem)
    .use(ElButton)
    .use(ElTabs)
    .use(ElTabPane)
    .use(ElEmpty)
    .use(ElPagination as any)

    .use(ElInput)
    .use(ElInputNumber)
    .use(ElSelect)
    .use(ElOption as any)
    .use(ElCheckboxGroup)
    .use(ElCheckbox)
    .use(ElRadioGroup)
    .use(ElRadio)
    .use(ElDatePicker as any)
    .use(ElTimePicker as any)

    .use(ElScrollbar)
    .use(ElPopper)

    .use(ElTree)
    .use(ElDropdown)
    .use(ElDropdownMenu)
    .use(ElDropdownItem)
    .use(ElTooltip as any)
    .use(ElTag)
    .use(ElDialog)
    .use(ElSpace)
    .use(ElTransfer);
}
