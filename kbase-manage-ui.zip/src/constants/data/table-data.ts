import { TableColumnModel, TableModel } from "@/model/entity/TabelModel";

const database = (): TableModel => {
  return new TableModel({
    name: "database",
    showPage: true,
    columns: [
      new TableColumnModel({
        prop: "label",
        label: "名称"
      }),
      new TableColumnModel({
        prop: "type",
        dict: "TABLE_TYPE",
        label: "类型"
      }),
      /* TODO 获得表所在主机IP KBase_GetTableHostIP（暂不展示到列表）*/
      /*new TableColumnModel({
        prop: "ip",
        label: "主机ip"
      }),*/
      new TableColumnModel({
        prop: "own",
        label: "拥有者"
      }),
      new TableColumnModel({
        prop: "relName",
        label: "关联表名"
      }),
      /* TODO 暂不展示到列表*/
      /*new TableColumnModel({
        prop: "relPk",
        label: "关联主键"
      }),*/
      new TableColumnModel({
        prop: "ct",
        label: "记录数"
      }),
      new TableColumnModel({
        prop: "size",
        label: "文件大小"
      }),
      new TableColumnModel({
        prop: "createTime",
        label: "建立时间"
      }),
      new TableColumnModel({
        prop: "updateTime",
        label: "修改时间"
      }),
      new TableColumnModel({
        prop: "url",
        label: "路径"
      })
    ]
  });
};

/*数据库用户列*/
const userField = (): TableModel => {
  return new TableModel({
    name: "userField",
    showPage: false,
    columns: [
      new TableColumnModel({
        prop: "user",
        label: "名称"
      }),
      new TableColumnModel({
        prop: "password",
        label: "密码"
      }),
      new TableColumnModel({
        prop: "begindate",
        label: "开户日期"
      }),
      new TableColumnModel({
        prop: "enddate",
        label: "中止日期"
      }),
      new TableColumnModel({
        prop: "maxlogin",
        label: "连接数" // len
      }),
      new TableColumnModel({
        prop: "stopuse",
        label: "是否停用" // code
      })
    ]
  });
};
/*数据库用户组列*/
const userGroupField = (): TableModel => {
  return new TableModel({
    name: "userGroupField",
    showPage: false,
    columns: [
      new TableColumnModel({
        prop: "team",
        label: "名称"
      }),
      new TableColumnModel({
        prop: "introduction",
        label: "描述"
      })
    ]
  });
};
/*数据表列*/
const dataTableField = (): TableModel => {
  return new TableModel({
    name: "dataTableField",
    showPage: false,
    columns: [
      new TableColumnModel({
        prop: "name",
        label: "名称"
      }),
      new TableColumnModel({
        prop: "aliasName",
        label: "别名"
      }),
      new TableColumnModel({
        prop: "dispName",
        label: "显示名称"
      }),
      new TableColumnModel({
        prop: "data",
        dict: "FIELD_TYPE",
        label: "数据类型"
      }),
      new TableColumnModel({
        prop: "len",
        label: "长度" // len
      }),
      new TableColumnModel({
        prop: "code",
        label: "编码" // code
      }),
      new TableColumnModel({
        prop: "index",
        dict: "INDEX_TYPE",
        label: "索引类型" // index
      }),
      new TableColumnModel({
        prop: "indexType",
        dict: "INDEX_MODE",
        label: "索引模式" // indexType
      }) /*,
      new TableColumnModel({
        /!*TODO 列序号待确认*!/
        prop: "fieldOffset",
        label: "序号" //
      })*/
    ]
  });
};
/*存储空间*/
const storeSpace = (): TableModel => {
  return new TableModel({
    name: "storeSpace",
    showPage: false,
    columns: [
      new TableColumnModel({
        prop: "name",
        label: "名称"
      }),
      new TableColumnModel({
        prop: "type",
        label: "类型"
      }),
      new TableColumnModel({
        prop: "fields",
        label: "列信息"
      })
    ]
  });
};
/*索引空间*/
const indexSpace = (): TableModel => {
  return new TableModel({
    name: "indexSpace",
    showPage: false,
    columns: [
      new TableColumnModel({
        prop: "name",
        label: "名称"
      }),
      new TableColumnModel({
        prop: "fields",
        label: "列信息"
      })
    ]
  });
};
/*映射字段*/
const fieldMapTable = (): TableModel => {
  return new TableModel({
    name: "fieldMapTable",
    showPage: false,
    columns: [
      new TableColumnModel({
        prop: "mapNum",
        label: "映射字段"
      }),
      new TableColumnModel({
        prop: "srcNum",
        label: "源字段"
      }),
      new TableColumnModel({
        prop: "weight",
        label: "主参数"
      }),
      new TableColumnModel({
        prop: "property",
        label: "参数1"
      }),
      new TableColumnModel({
        prop: "maxcount",
        label: "参数2"
      })
    ]
  });
};
/*排序索引*/
const sortIndexTable = (): TableModel => {
  return new TableModel({
    name: "sortIndex",
    showPage: false,
    columns: [
      new TableColumnModel({
        prop: "dict",
        label: "排序词典"
      }),
      new TableColumnModel({
        prop: "col",
        label: "字段名称"
      }),
      new TableColumnModel({
        prop: "rownum",
        label: "排序行数"
      }),
      new TableColumnModel({
        prop: "size",
        label: "大小"
      })
    ]
  });
};
export { database, dataTableField, userField, userGroupField, indexSpace, storeSpace, fieldMapTable, sortIndexTable };
