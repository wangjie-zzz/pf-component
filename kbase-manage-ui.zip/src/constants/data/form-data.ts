import { FormFieldModel, FormModel, FormTypeEnum } from "@/model/entity/FormModel";
const toFormValue = (form: FormModel, value?: any) => {
  if (!value) {
    value = {};
  }
  form.fields.forEach(f => {
    if (!value[f.prop] && value[f.prop] !== 0) value[f.prop] = f.value;
  });
  return value;
};
const testForm = (): FormModel => {
  return new FormModel({
    name: "testForm",
    fields: [
      new FormFieldModel({
        prop: "name",
        label: "姓名",
        type: FormTypeEnum.INPUT.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "sex",
        label: "性别",
        type: FormTypeEnum.RADIO.code,
        required: true,
        options: [
          { key: "1", value: "男" },
          { key: "0", value: "女" }
        ],
        rules: []
      }),
      new FormFieldModel({
        prop: "age",
        label: "年龄",
        type: FormTypeEnum.NUMBER.code,
        value: 0,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "class",
        label: "班级",
        type: FormTypeEnum.SELECT.code,
        options: [
          { key: "1", value: "A班" },
          { key: "0", value: "B班" }
        ],
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "hobby",
        label: "爱好",
        type: FormTypeEnum.CHECKBOX.code,
        options: [
          { key: "1", value: "男" },
          { key: "0", value: "女" }
        ],
        value: [],
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "remark",
        label: "备注",
        type: FormTypeEnum.TEXTAREA.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "birthday",
        label: "生日",
        type: FormTypeEnum.DATE.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "birthdayTime",
        label: "生日时间",
        type: FormTypeEnum.TIME.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "joinTime",
        label: "入学时间",
        type: FormTypeEnum.DATETIME.code,
        required: true,
        rules: []
      })
    ],
    labelWidth: "120px",
    rules: []
  });
};

const userForm = (): FormModel => {
  return new FormModel({
    name: "userForm",
    fields: [
      new FormFieldModel({
        prop: "user",
        label: "用户名称",
        type: FormTypeEnum.INPUT.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "password",
        label: "密码",
        type: FormTypeEnum.INPUT.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "begindate",
        label: "开户日期",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "enddate",
        label: "中止日期",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "dept",
        label: "工作单位",
        type: FormTypeEnum.INPUT.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "email",
        label: "email",
        type: FormTypeEnum.INPUT.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "telephone",
        label: "电话",
        type: FormTypeEnum.INPUT.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "introduction",
        label: "备注",
        spanCol: 2,
        type: FormTypeEnum.TEXTAREA.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "maxlogin",
        label: "同时在线用户",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "stopuse",
        label: "停止使用",
        type: FormTypeEnum.RADIO.code,
        options: [
          { key: 1, value: "是" },
          { key: 0, value: "否" }
        ],
        required: true,
        rules: []
      })
    ],
    labelWidth: "120px",
    rules: []
  });
};
const userGroupForm = (): FormModel => {
  return new FormModel({
    name: "userGroupForm",
    fields: [
      new FormFieldModel({
        prop: "team",
        label: "组名称",
        type: FormTypeEnum.INPUT.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "introduction",
        label: "描述",
        type: FormTypeEnum.TEXTAREA.code,
        required: true,
        rules: []
      })
    ],
    labelWidth: "120px",
    rules: []
  });
};
const dataTable = (): FormModel => {
  return new FormModel({
    name: "dataTable",
    fields: [
      new FormFieldModel({
        prop: "label",
        label: "表名",
        type: FormTypeEnum.INPUT.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "aliasName",
        label: "别名",
        type: FormTypeEnum.INPUT.code,
        rules: []
      }),
      new FormFieldModel({
        prop: "type",
        label: "类型",
        placeholder: "请选择表类型",
        type: FormTypeEnum.SELECT.code,
        required: true,
        dict: "TABLE_TYPE",
        rules: []
      }),
      new FormFieldModel({
        prop: "own",
        label: "拥有者",
        type: FormTypeEnum.INPUT.code,
        rules: []
      }),
      new FormFieldModel({
        prop: "version",
        label: "版本号",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "subVersion",
        label: "次版本号",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "size",
        label: "文件大小",
        type: FormTypeEnum.INPUT.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "fieldNum",
        label: "字段个数",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "ct",
        label: "记录数",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "createTime",
        label: "建立时间",
        type: FormTypeEnum.DATETIME.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "updateTime",
        label: "修改时间",
        type: FormTypeEnum.DATETIME.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "url",
        label: "路径",
        type: FormTypeEnum.INPUT.code,
        required: true,
        rules: []
      })
      /*, TODO 暂不展示
      new FormFieldModel({
        prop: "ip",
        label: "主机ip",
        type: FormTypeEnum.INPUT.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "datalist",
        label: "数据节点列表",
        type: FormTypeEnum.INPUT.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "notifylist",
        label: "调度节点列表",
        type: FormTypeEnum.INPUT.code,
        required: true,
        rules: []
      })*/
    ],
    labelWidth: "120px",
    rules: []
  });
};
const login = (): FormModel => {
  return new FormModel({
    name: "login",
    fields: [
      new FormFieldModel({
        prop: "ip",
        type: FormTypeEnum.INPUT.code,
        required: true,
        placeholder: "请输入ip地址",
        prefix: "el-icon-monitor",
        rules: [{ pattern: /^((25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))\.){3}(25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))$/, message: "请输入正确的ip地址" }]
      }),
      new FormFieldModel({
        prop: "port",
        value: "4567",
        placeholder: "请输入端口",
        prefix: "el-icon-thumb",
        type: FormTypeEnum.INPUT.code,
        required: true,
        rules: [{ pattern: /^\d{4}$/, message: "请输入正确的端口号" }]
      }),
      new FormFieldModel({
        prop: "user",
        value: "DBOWN",
        placeholder: "请输入用户名",
        prefix: "el-icon-user",
        type: FormTypeEnum.INPUT.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "password",
        placeholder: "请输入密码",
        showPassword: true,
        prefix: "el-icon-unlock",
        type: FormTypeEnum.INPUT.code,
        // required: true,
        rules: []
      })
    ],
    // labelWidth: "120px",
    rules: []
  });
};
const systemParam = (): FormModel => {
  return new FormModel({
    name: "systemParam",
    fields: [
      new FormFieldModel({
        prop: "serveIp",
        label: "服务器ip",
        type: FormTypeEnum.INPUT.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "servePort",
        label: "服务器工作端口",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "prePort",
        label: "并行系统端口",
        type: FormTypeEnum.INPUT.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "serveProdNum",
        label: "服务器产品号",
        type: FormTypeEnum.INPUT.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "serveVersion",
        label: "服务器版本号",
        type: FormTypeEnum.INPUT.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "serveCompileDate",
        label: "服务器编译日期",
        type: FormTypeEnum.DATE.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "engCompileDate",
        label: "引擎编译日期",
        type: FormTypeEnum.DATE.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "engVersion",
        label: "引擎版本号",
        type: FormTypeEnum.INPUT.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "maxOlUserCt",
        label: "最大在线用户数",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "connCt",
        label: "当前连接数",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "OlUserCt",
        label: "登录用户总数",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "qps",
        label: "最大并发数",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "autoCloseTime",
        label: "自动断开时间",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "timeout",
        label: "操作超时时间",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "serveSysMem",
        label: "服务器系统内存",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "serveFreeMem",
        label: "服务器可用内存",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "serveRunTime",
        label: "服务器稳定运行",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "tableCt",
        label: "表总数",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "viewCt",
        label: "视图总数",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "userCt",
        label: "用户总数",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "cmdCt",
        label: "命令总数",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "serveRunState",
        label: "服务器运行状态",
        type: FormTypeEnum.INPUT.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "logLevel",
        label: "系统日志",
        type: FormTypeEnum.INPUT.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "logDays",
        label: "系统日志记录天数",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        rules: []
      })
    ],
    labelWidth: "150px",
    rules: []
  });
};
const sortIndex = (): FormModel => {
  return new FormModel({
    name: "sortIndex",
    fields: [
      new FormFieldModel({
        prop: "dict",
        label: "指定词典",
        type: FormTypeEnum.SELECT.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "fields",
        label: "指定字段",
        multiple: true,
        type: FormTypeEnum.SELECT.code,
        required: true,
        rules: []
      })
    ],
    // labelWidth: "120px",
    rules: []
  });
};
const fieldMap = (): FormModel => {
  return new FormModel({
    name: "fieldMap",
    fields: [
      new FormFieldModel({
        prop: "srcNum",
        label: "源字段",
        type: FormTypeEnum.SELECT.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "mapNum",
        label: "映射字段",
        type: FormTypeEnum.SELECT.code,
        required: true,
        rules: []
      }),
      new FormFieldModel({
        prop: "weight",
        label: "主参数",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        value: 0,
        rules: []
      }),
      new FormFieldModel({
        prop: "property",
        label: "参数1",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        value: 0,
        rules: []
      }),
      new FormFieldModel({
        prop: "maxcount",
        label: "参数2",
        type: FormTypeEnum.NUMBER.code,
        required: true,
        value: 0,
        rules: []
      })
    ],
    // labelWidth: "120px",
    rules: []
  });
};
export { testForm, toFormValue, dataTable, login, userForm, userGroupForm, sortIndex, fieldMap, systemParam };
