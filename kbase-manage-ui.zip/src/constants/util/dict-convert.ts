import { authService } from "@/services/auth-service";
import { SysDict } from "@/model/SysDict";
import { computed, ComputedRef } from "vue";
import { Options } from "@/model/entity/FormModel";

export function useDict() {
  const convertDict = (name: string, code: string): string => {
    if (name) {
      const dicts: SysDict[] =
        authService
          .getDict()
          .filter(d => d.name === name)
          .filter(d1 => d1.key === String(code)) || [];
      if (dicts.length > 0) return dicts[0].value;
    }
    return code;
  };
  const convertOptions = (dict: string): Options[] => {
    if (!dict) return [];
    return authService
      .getDict()
      .filter(d => d.name === dict)
      .map(d1 => {
        return {
          key: Number(d1.key),
          value: d1.value
        };
      });
  };
  return { convertDict, convertOptions };
}
