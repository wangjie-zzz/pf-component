const HEADER_TYPE = "HeaderTypeEnum";

const HeaderTypeEnum = {
  BASE: { code: "base", name: "BASE" },
  AUTH: { code: "auth", name: "AUTH" }
};
export { HEADER_TYPE, HeaderTypeEnum };
