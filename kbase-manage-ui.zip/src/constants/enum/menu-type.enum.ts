const MENU_TYPE = "MenuTypeEnum";

const MenuTypeEnum = {
  LINK: { code: "1", name: "" },
  OUT_LINK: { code: "2", name: "" },
  BUTTON: { code: "3", name: "" }
};
export { MENU_TYPE, MenuTypeEnum };
