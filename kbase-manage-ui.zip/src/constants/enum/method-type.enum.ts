const METHOD_TYPE = "MethodTypeEnum";

const MethodTypeEnum = {
  GET: { code: "get", name: "" },
  POST: { code: "post", name: "" },
  PUT: { code: "put", name: "" },
  DELETE: { code: "delete", name: "" }
};
export { METHOD_TYPE, MethodTypeEnum };
