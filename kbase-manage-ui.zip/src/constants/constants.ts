export class Constants {
  static TOKEN = "token";
  static USER = "user";
  static DICT = "dict";
  static CODE = {
    SUCCESS: 200,
    SERVER_FAIL: 500,
    INVALID_TOKEN: 403
  };
  static PERMITALL = ["/login"];
  static DEFAULT_USERNAME = "defaultUser";
  static DEFAULT_PWD = "123456";
  static DEFAULT_KBASE = "PItfh0Dj2dePO3kIeXMPlZtN1VfaYwoUNikbtsDDzvpW9s5jZuUUaTZKElAoIcUz16DJXcRk+/DwPRWOp03otZGKoUNahbZcM3CtaGcIjLlYQcwZrrw/8PgGxMAjv9gDluATjLlKT5pVrHb9Gu8WCtL61IZDW4JdVieMz7HNHpUrwDHs2cjjkK8rAYHNxoxMBVAOrJLLwzaupVNwu1Rjp/DdJJwoThcZ8RBL+yWxvQQKqMBEk6sxE9IZejXpowCO9JTCrQ3Dmsgx87wnlET7E93eXyshuxDKDRMdNQ74e8x0O6tbiL96b/KqwMdAZtDKA6wZQRBQ5JSIfppXMawBDg==";
}
