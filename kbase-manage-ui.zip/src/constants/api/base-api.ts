import { MethodTypeEnum } from "@/constants/enum/method-type.enum";
import { HeaderTypeEnum } from "@/constants/enum/header-type.enum";
export interface Api {
  [key: string]: {
    url: string;
    method: string;
    header: string;
  };
}
export class BaseApi {
  baseUrl: string;
  prefix: string;
  permit: string;
  project: string;
  /* dataApi;
  authApi;
  fileApi;
  modelApi; */

  constructor(project?: string) {
    this.baseUrl = process.env.VUE_APP_BASE_URL || "/kmApi";
    this.prefix = process.env.VUE_APP_API_PREFIX || "";
    this.project = project || "";
    this.permit = "/permitall";
    // this.init(project)
  }

  authApi(project: string) {
    this.project = project ? "/" + project : this.project;
    return {
      token: {
        url: this.baseUrl + this.prefix + this.project + "/auth/token",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.BASE.code
      },
      login: {
        url: this.baseUrl + this.prefix + this.project + "/auth/login",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.BASE.code
      },
      user: {
        url: this.baseUrl + this.prefix + this.project + "/auth/user",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.BASE.code
      }
    };
  }

  dataApi(project: string) {
    this.project = project ? "/" + project : this.project;
    return {
      data: {
        url: this.baseUrl + this.prefix + this.project + "/data",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      cite: {
        url: this.baseUrl + this.prefix + this.project + "/cite",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      cited: {
        url: this.baseUrl + this.prefix + this.project + "/cited",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      similar: {
        url: this.baseUrl + this.prefix + this.project + "/similar",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      recommend: {
        url: this.baseUrl + this.prefix + this.project + "/recommend",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      }
    };
  }

  modelApi(project: string) {
    this.project = project ? "/" + project : this.project;
    return {
      model: {
        url: this.baseUrl + this.prefix + this.project + "/model",
        method: MethodTypeEnum.PUT.code,
        header: HeaderTypeEnum.BASE.code
      },
      allModel: {
        url: this.baseUrl + this.prefix + this.project + "/model/all",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.BASE.code
      },
      ui: {
        url: this.baseUrl + this.prefix + this.project + "/ui",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      }
    };
  }

  fileApi(project: string) {
    this.project = project ? "/" + project : this.project;
    return {};
  }
}
