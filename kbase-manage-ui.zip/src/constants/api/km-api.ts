import { Api, BaseApi } from "@/constants/api/base-api";
import { MethodTypeEnum } from "@/constants/enum/method-type.enum";
import { HeaderTypeEnum } from "@/constants/enum/header-type.enum";
import { App } from "vue";
// import { Constants } from "@/constants/constants";

class KmApi extends BaseApi {
  install(app: App) {
    app.config.globalProperties.$kmApi = this;
  }
  dictApi: Api = {};
  userApi: Api = {};
  dbManageApi: Api = {};
  systemInfoApi: Api = {};
  sysManageApi: Api = {};
  constructor() {
    super();
    this.initKm();
  }

  initKm() {
    this.dictApi = {
      sysDict: {
        url: this.baseUrl + "/sys-dict/list",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      }
    };
    this.userApi = {
      login: {
        url: this.baseUrl + "/login",
        method: MethodTypeEnum.POST.code,
        header: HeaderTypeEnum.BASE.code
      },
      closeConnect: {
        url: this.baseUrl + "/user/close-connect",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      getPuk: {
        url: this.baseUrl + "/user" + this.permit + "/getPuk",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.BASE.code
      },
      list: {
        url: this.baseUrl + "/user" + "/list",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      groupList: {
        url: this.baseUrl + "/user" + "/group-list",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      addGroup: {
        url: this.baseUrl + "/user" + "/add-group",
        method: MethodTypeEnum.POST.code,
        header: HeaderTypeEnum.AUTH.code
      },
      updGroup: {
        url: this.baseUrl + "/user" + "/upd-group",
        method: MethodTypeEnum.POST.code,
        header: HeaderTypeEnum.AUTH.code
      },
      updUser: {
        url: this.baseUrl + "/user" + "/upd-user",
        method: MethodTypeEnum.POST.code,
        header: HeaderTypeEnum.AUTH.code
      },
      addUser: {
        url: this.baseUrl + "/user" + "/add-user",
        method: MethodTypeEnum.POST.code,
        header: HeaderTypeEnum.AUTH.code
      },
      delUser: {
        url: this.baseUrl + "/user" + "/del-user",
        method: MethodTypeEnum.POST.code,
        header: HeaderTypeEnum.AUTH.code
      },
      delGroup: {
        url: this.baseUrl + "/user" + "/del-group",
        method: MethodTypeEnum.POST.code,
        header: HeaderTypeEnum.AUTH.code
      },
      updUserOnGroup: {
        url: this.baseUrl + "/user" + "/upd-users-ongroup",
        method: MethodTypeEnum.POST.code,
        header: HeaderTypeEnum.AUTH.code
      },
      updGroupOnUser: {
        url: this.baseUrl + "/user" + "/upd-group-onusers",
        method: MethodTypeEnum.POST.code,
        header: HeaderTypeEnum.AUTH.code
      }
    };
    this.dbManageApi = {
      list: {
        url: this.baseUrl + "/db-manage/list",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      indexSpace: {
        url: this.baseUrl + "/db-manage/index-space-list",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      sortIndex: {
        url: this.baseUrl + "/db-manage/sort-index-list",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      storeSpace: {
        url: this.baseUrl + "/db-manage/store-space-list",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      fieldMap: {
        url: this.baseUrl + "/db-manage/field-map-list",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      create: {
        url: this.baseUrl + "/db-manage/create",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      delete: {
        url: this.baseUrl + "/db-manage/delete",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      tableListPage: {
        url: this.baseUrl + "/db-manage/table-list-page",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      tableList: {
        url: this.baseUrl + "/db-manage/table-list",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      tableDetail: {
        url: this.baseUrl + "/db-manage/table-detail",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      }
    };
    this.sysManageApi = {
      GetFieldType: {
        url: this.baseUrl + "/system/field-type",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      GetIndexType: {
        url: this.baseUrl + "/system/index-type",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      GetDictList: {
        url: this.baseUrl + "/dict/list",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      DictRefresh: {
        url: this.baseUrl + "/dict/refresh",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      DictDel: {
        url: this.baseUrl + "/dict/del",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      FS: {
        url: this.baseUrl + "/fs/list",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      ShowReginfo: {
        url: this.baseUrl + "/reg/info",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      Register: {
        url: this.baseUrl + "/reg/register",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      }
    };
    this.systemInfoApi = {
      param: {
        url: this.baseUrl + "/system-info/param",
        method: MethodTypeEnum.GET.code,
        header: HeaderTypeEnum.AUTH.code
      },
      paramUpd: {
        url: this.baseUrl + "/system-info/upd-param",
        method: MethodTypeEnum.POST.code,
        header: HeaderTypeEnum.AUTH.code
      }
    };
  }
}
export const kmApi = new KmApi();
