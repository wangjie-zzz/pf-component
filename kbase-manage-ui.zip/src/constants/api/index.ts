import { clientService } from "@/services/client-service";
import { authService } from "@/services/auth-service";
import { kmApi } from "@/constants/api/km-api";
import { App } from "vue";

export function kmInstall(app: App): App {
  return app
    .use(authService)
    .use(clientService)
    .use(kmApi);
}
