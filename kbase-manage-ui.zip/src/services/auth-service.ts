import { Constants } from "@/constants/constants";
import { App } from "vue";
import { clientService } from "@/services/client-service";
import { kmApi } from "@/constants/api/km-api";
import { useNotice } from "@/components/element-plus/notice";
import { SysDict } from "@/model/SysDict";

class AuthService {
  app: any;
  install(app: App) {
    this.app = app;
    app.config.globalProperties.$auth = this;
  }
  login(params: string): Promise<boolean> {
    const { message } = useNotice();
    const user = {
      username: Constants.DEFAULT_USERNAME,
      password: Constants.DEFAULT_PWD
    };
    return clientService.general(kmApi.userApi.login, user, params).then(response => {
      if (response.code === Constants.CODE.SUCCESS) {
        this.setToken({ accessToken: response.data }, { idenId: Constants.DEFAULT_USERNAME });
        return this.initDict().then(dres => {
          if (dres) {
            message.success(response.message);
          } else {
            message.error("字典初始化失败");
          }
          return Promise.resolve(true);
        });
      } else {
        message.error(response.message);
        return Promise.resolve(false);
      }
    });
  }
  initDict(): Promise<boolean> {
    return clientService.general<SysDict[]>(kmApi.dictApi.sysDict).then(response => {
      if (response.code === Constants.CODE.SUCCESS) {
        this.setDict(response.data);
        return Promise.resolve(true);
      } else {
        return Promise.resolve(false);
      }
    });
  }
  clearCache() {
    this.clearToken();
    this.clearDict();
  }
  setToken(token: any, user: any): void {
    sessionStorage.setItem(Constants.TOKEN, JSON.stringify(token));
    sessionStorage.setItem(Constants.USER, JSON.stringify(user));
  }
  clearToken(): void {
    sessionStorage.removeItem(Constants.TOKEN);
    sessionStorage.removeItem(Constants.USER);
  }

  refreshToken() {
    console.log("refreshtoken....");
  }
  getUser() {
    const userStr = sessionStorage.getItem(Constants.USER);
    if (userStr) {
      const user = JSON.parse(userStr);
      return user;
    }
  }

  getUserIdentity(): string {
    return this.getUser()?.idenId;
  }

  checkLogin(): boolean {
    const identity = this.getUserIdentity();
    return !!identity;
  }

  getToken() {
    const tokenStr = sessionStorage.getItem(Constants.TOKEN);
    if (tokenStr) {
      const token = JSON.parse(tokenStr);
      return token;
    }
  }

  checkToken(): boolean {
    const currentTimeStamp = new Date().getTime();
    const token = this.getToken() || {};
    const expiratTimeStamp = token.time + (token.expiresIn - 300) * 1000;
    if (currentTimeStamp > expiratTimeStamp) {
      return false;
    }
    return true;
  }

  setDict(data: SysDict[]): void {
    sessionStorage.setItem(Constants.DICT, JSON.stringify(data));
  }

  getDict(): SysDict[] {
    const dictStr = sessionStorage.getItem(Constants.DICT);
    if (dictStr) {
      const dicts = JSON.parse(dictStr);
      return dicts;
    }
    return [];
  }
  clearDict() {
    sessionStorage.removeItem(Constants.DICT);
  }
}
export const authService = new AuthService();
