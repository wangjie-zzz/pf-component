<template>
  <div>
    <h3>数值</h3>
    <el-space wrap>
      <div v-for="item in records.FITC_NUM" :key="item">
        <el-button type="text"> {{ item }} </el-button>
      </div>
    </el-space>
    <h3>字符串</h3>
    <el-space wrap>
      <div v-for="item in records.FITC_CHAR" :key="item">
        <el-button type="text"> {{ item }} </el-button>
      </div>
    </el-space>
    <h3>文本</h3>
    <el-space wrap>
      <div v-for="item in records.FITC_TEXT" :key="item">
        <el-button type="text"> {{ item }} </el-button>
      </div>
    </el-space>
    <h3>其他</h3>
    <el-space wrap>
      <div v-for="item in records.FITC_OTHER" :key="item">
        <el-button type="text"> {{ item }} </el-button>
      </div>
    </el-space>
  </div>
</template>

<script lang="ts">
/* eslint-disable */
import { defineComponent, ref } from "vue";

import { clientService } from "@/services/client-service";
import { kmApi } from "@/constants/api/km-api";
import { useNotice } from "@/components/element-plus/notice";
import { Constants } from "@/constants/constants";

export default defineComponent({
  name: "IndexType",
  setup() {
    const { message } = useNotice();
    const records = ref({});
    clientService
      .general<any>(kmApi.sysManageApi.GetIndexType, undefined)
      .then(function(res) {
          if (res.code != Constants.CODE.SUCCESS) {
                message.error(res.message);
            } else {
                records.value = res.data;
            }
      });
    return {
      records
    };
  }
});
</script>

<style scoped></style>
