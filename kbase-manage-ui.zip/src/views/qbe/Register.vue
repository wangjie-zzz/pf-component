<template>
  <div>
    <el-button @click="dialogFormVisible = true">SSH连接</el-button>
    <el-button v-if="connected & !register" @click="handleRegister">注册</el-button>
    <el-form label-position="left" label-width="120px">
      <el-form-item label="系统识别码">
        <el-input v-model="reginfo[0]" readonly></el-input>
      </el-form-item>
      <el-form-item label="注册码">
        <el-input v-model="reginfo[1]"></el-input>
      </el-form-item>
    </el-form>
    <el-dialog title="SSH远程链接" v-model="dialogFormVisible">
      <el-form :model="form">
        <el-form-item>
          <el-input v-model="form.host" placeholder="Enter username@hostname"></el-input>
        </el-form-item>
        <el-form-item>
          <el-input v-model="form.pass" placeholder="Enter password"></el-input>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button type="primary" @click="handleConnect">连接</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from "vue";
import { login, toFormValue } from "@/constants/data/form-data";

import { clientService } from "@/services/client-service";
import { kmApi } from "@/constants/api/km-api";
import { useNotice } from "@/components/element-plus/notice";
import { Constants } from "@/constants/constants";
import { ElForm, ElFormItem } from "element-plus";

export default {
  name: "Register",
  components: {
    ElForm,
    ElFormItem
  },
  setup() {
    const loginConfig = login();
    const loginInfo: any = toFormValue(loginConfig);
    const dialogFormVisible = ref(true);
    const form = ref({
      host: "root@192.168.80.128",
      pass: "123456"
    });
    const { message } = useNotice();

    const reginfo = ref([]);
    const connected = ref(false);
    const register = ref(false);

    const handleConnect = () => {
      clientService.general<any>(kmApi.sysManageApi.ShowReginfo, form.value).then(function(res) {
        if (res.code != Constants.CODE.SUCCESS) {
          message.error(res.message);
        } else {
          const info = res.data;
          if (info && info[1] != "None") {
            register.value = true;
          }
          reginfo.value = res.data;
          connected.value = true;
          dialogFormVisible.value = false;
        }
      });
    };

    const handleRegister = () => {
      const data = {
        code: reginfo.value[1],
        ...form.value
      };
      clientService.general<any>(kmApi.sysManageApi.Register, data).then(function(res) {
        if (res.code != Constants.CODE.SUCCESS) {
          message.error(res.data || res.message);
        } else {
          message.success("注册成功");
        }
      });
    };

    return {
      loginConfig,
      loginInfo,
      dialogFormVisible,
      form,
      handleConnect,
      reginfo,
      register,
      connected,
      handleRegister
    };
  }
};
</script>

<style scoped></style>
