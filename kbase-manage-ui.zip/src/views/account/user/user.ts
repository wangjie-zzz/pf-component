import { clientService } from "@/services/client-service";
import { kmApi } from "@/constants/api/km-api";
import { Constants } from "@/constants/constants";
import { useNotice } from "@/components/element-plus/notice";

export const useUser = () => {
  const { loading, message } = useNotice();
  const list = (): Promise<any[]> => {
    loading.open();
    return clientService.general<any[]>(kmApi.userApi.list).then(res => {
      loading.close();
      if (res.code === Constants.CODE.SUCCESS) {
        return res.data;
      } else {
        message.error(res.message);
        return [];
      }
    });
  };
  const del = (ckUserList: any[]): Promise<boolean> => {
    if (ckUserList && ckUserList.length > 0) {
      const users: string[] = ckUserList.map(u => u.user);
      return clientService.general(kmApi.userApi.delUser, undefined, users).then(res => {
        if (res.code === Constants.CODE.SUCCESS) {
          message.success(res.message);
        } else {
          message.error(res.message);
        }
        return res.code === Constants.CODE.SUCCESS;
      });
    } else {
      message.error("请选中一条或多条数据");
      return Promise.resolve(false);
    }
  };
  const listOnUser = (userName: string, allGroup: any[]): Promise<any[]> => {
    return clientService.general(kmApi.userApi.groupList, { userName }).then(res => {
      if (res.code === Constants.CODE.SUCCESS) {
        allGroup.splice(0, allGroup.length);
        allGroup.push(
          ...(res.data as any).map((e: any, idx: number) => {
            return {
              key: idx,
              ...e
            };
          })
        );
        return allGroup.map((e, idx) => {
          if (e.has) return idx;
        });
      } else {
        message.error(res.message);
        return [];
      }
    });
  };
  const updGroupOnUser = (groupList: any[], username: string): Promise<boolean> => {
    const params =
      groupList && groupList.length > 0
        ? groupList
            .filter(g => g && g.team)
            .map(team => {
              return { team: team.team, user: username };
            })
        : [];
    return clientService.general(kmApi.userApi.updGroupOnUser, undefined, { list: params, name: username }).then(res => {
      if (res.code === Constants.CODE.SUCCESS) {
        message.success(res.message);
      } else {
        message.error(res.message);
      }
      return res.code === Constants.CODE.SUCCESS;
    });
  };
  const add = (formInfo: any, upd?: boolean): Promise<boolean> => {
    if (upd) {
      return clientService.general(kmApi.userApi.updUser, undefined, formInfo).then(res => {
        if (res.code === Constants.CODE.SUCCESS) {
          message.success(res.message);
        } else {
          message.error(res.message);
        }
        return res.code === Constants.CODE.SUCCESS;
      });
    } else {
      return clientService.general(kmApi.userApi.addUser, undefined, formInfo).then(res => {
        if (res.code === Constants.CODE.SUCCESS) {
          message.success(res.message);
        } else {
          message.error(res.message);
        }
        return res.code === Constants.CODE.SUCCESS;
      });
    }
  };
  return { list, add, del, listOnUser, updGroupOnUser };
};
