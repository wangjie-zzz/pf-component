<template>
  <div class="km-flex km-flex-column km-bgwhite km-p-15">
    <div class="km-text-right km-pt-10">
      <el-button size="mini" icon="el-icon-refresh" @click="getUserList" />
      <el-button size="mini" @click="deleteUser">删除选中用户</el-button>
      <el-button size="mini" type="primary" @click="addUserClick">添加新用户</el-button>
      <!--      <el-button size="mini" type="primary" @click="addUserToGroup">添加到组中</el-button>-->
    </div>
    <el-table
      class="km-mt-10"
      :data="userList"
      :config="tableConfig"
      @selection-change="
        data => {
          ckUserList = data;
        }
      "
    >
      <el-table-column label="操作" fixed="right" width="80">
        <template #default="scope">
          <el-tooltip effect="light" placement="left" trigger="hover">
            <i class="km-fs-18 el-icon-menu el-button&#45;&#45;text"></i>
            <template #content>
              <div class="km-flex km-flex-column km-flex-0">
                <el-button @click="handleClick(scope.row, 'edit')" type="text" size="mini">修改</el-button>
                <el-button @click="handleClick(scope.row, 'delToGroup')" type="text" size="mini">组管理</el-button>
                <el-button @click="handleClick(scope.row, 'ipControl')" type="text" size="mini">ip访问控制</el-button>
                <el-button @click="handleClick(scope.row, 'dataGrant')" type="text" size="mini">数据访问授权</el-button>
              </div>
            </template>
          </el-tooltip>
        </template>
      </el-table-column>
    </el-table>
    <el-dialog title="创建用户" v-model="dialogVisible">
      <div class="km-flex km-ai-center km-mr-20">
        <el-form ref="userFormRef" :config="formConfig" :model="formInfo"></el-form>
      </div>
      <template #footer>
        <span>
          <el-button @click="dialogVisible = false">取消</el-button>
          <el-button type="primary" @click="addUser">确定</el-button>
          <el-button type="primary">帮助</el-button>
        </span>
      </template>
    </el-dialog>

    <el-dialog title="组管理" v-model="dialogVisible0">
      <el-transfer
        v-model="hasGroup"
        :titles="['其他组', '用户当前所在组']"
        :format="{
          noChecked: '${total}',
          hasChecked: '${checked}/${total}'
        }"
        :data="allGroup"
      >
        <!--@change="userChange"-->
        <template #default="{option}">
          <span>{{ option.team }}</span>
        </template>
      </el-transfer>
      <template #footer>
        <span>
          <el-button @click="dialogVisible0 = false">取消</el-button>
          <el-button type="primary" @click="updGroup">确定</el-button>
          <el-button type="primary">帮助</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script lang="ts">
import { defineComponent, reactive, Ref, ref } from "vue";
import { userField } from "@/constants/data/table-data";
import { useNotice } from "@/components/element-plus/notice";
import { toFormValue, userForm } from "@/constants/data/form-data";
import { useUser } from "@/views/account/user/user";

export default defineComponent({
  name: "User",
  setup() {
    const tableConfig = userField().checkbox();
    const userList: Ref<any[]> = ref([]);
    const ckUserList: Ref<any[]> = ref([]);

    const dialogVisible = ref(false);
    const formConfig = reactive(userForm());
    const userFormRef = ref(null);
    const formInfo = reactive(toFormValue(formConfig));
    const dialogVisible0 = ref(false);
    const allGroup: any[] = [];
    const hasGroup: Ref<any[]> = ref([]);
    const user: Ref<string> = ref("");
    const { message } = useNotice();
    const { list, del, listOnUser, updGroupOnUser, add } = useUser();
    const getUserList = () => {
      list().then(res => {
        userList.value = res;
      });
    };
    getUserList();
    const deleteUser = () => {
      del(ckUserList.value).then(res => {
        if (res) getUserList();
      });
    };
    const addUserToGroup = () => {
      message.error("待完善");
    };
    const addUserClick = () => {
      dialogVisible.value = true;
      formConfig.setDisable("user");
    };
    const addUser = () => {
      (userFormRef.value as any).validate((val: boolean) => {
        if (val) {
          if (!formConfig.getDisable("user")) {
            if (userList.value.findIndex(e => e.user === formInfo.user) > -1) {
              message.error("该用户名已存在");
              return;
            }
            add(formInfo).then(res => {
              if (res) {
                dialogVisible.value = false;
                getUserList();
              }
            });
          } else {
            add(formInfo, true).then(res => {
              if (res) {
                dialogVisible.value = false;
                getUserList();
              }
            });
          }
        }
      });
    };
    const getGroupOnUser = () => {
      listOnUser(user.value, allGroup).then(res => {
        hasGroup.value = res;
        dialogVisible0.value = true;
      });
    };
    const updGroup = () => {
      const groupList = hasGroup.value.map(idx => {
        if (!isNaN(idx) && idx > -1) {
          return allGroup[idx];
        }
      });
      updGroupOnUser(groupList, user.value).then(res => {
        if (res) {
          dialogVisible0.value = false;
        }
      });
    };
    const handleClick = (data: any, oper: string) => {
      switch (oper) {
        case "edit":
          dialogVisible.value = true;
          Object.assign(formInfo, data);
          formConfig.setDisable("user", true);
          break;
        case "delToGroup":
          user.value = data.user;
          getGroupOnUser();
          break;
        default:
          message.error("待完善");
      }
    };
    return {
      tableConfig,
      userList,
      ckUserList,
      dialogVisible,
      formConfig,
      userFormRef,
      formInfo,
      dialogVisible0,
      allGroup,
      hasGroup,
      getUserList,
      handleClick,
      deleteUser,
      addUser,
      addUserClick,
      addUserToGroup,
      updGroup
    };
  }
});
</script>
<style scoped lang="scss">
.#{$prefix} {
}
</style>
