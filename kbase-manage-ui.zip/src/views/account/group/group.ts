import { clientService } from "@/services/client-service";
import { kmApi } from "@/constants/api/km-api";
import { Constants } from "@/constants/constants";
import { useNotice } from "@/components/element-plus/notice";

export const useGroup = () => {
  const { loading, message } = useNotice();
  const list = (): Promise<any[]> => {
    loading.open();
    return clientService.general<any[]>(kmApi.userApi.groupList).then(res => {
      loading.close();
      if (res.code === Constants.CODE.SUCCESS) {
        return res.data;
      } else {
        message.error(res.message);
        return [];
      }
    });
  };
  const del = (ckGroupList: any[]): Promise<boolean> => {
    if (ckGroupList && ckGroupList.length > 0) {
      const groups: string[] = ckGroupList.map(u => u.team);
      return clientService.general(kmApi.userApi.delGroup, undefined, groups).then(res => {
        if (res.code === Constants.CODE.SUCCESS) {
          message.success(res.message);
        } else {
          message.error(res.message);
        }
        return res.code === Constants.CODE.SUCCESS;
      });
    } else {
      message.error("请选中一条或多条数据");
      return Promise.resolve(false);
    }
  };
  const listOnGroup = (allUsers: any[], groupName: string): Promise<any[]> => {
    return clientService.general(kmApi.userApi.list, { groupName }).then(res => {
      if (res.code === Constants.CODE.SUCCESS) {
        allUsers.splice(0, allUsers.length);
        allUsers.push(
          ...(res.data as any).map((e: any, idx: number) => {
            return {
              key: idx,
              ...e
            };
          })
        );
        return allUsers.map((e, idx) => {
          if (e.has) return idx;
        });
      } else {
        message.error(res.message);
        return [];
      }
    });
  };
  const updUserOnGroup = (userList: any[], groupName: string): Promise<boolean> => {
    const params =
      userList && userList.length > 0
        ? userList
            .filter(u => u && u.user)
            .map(user => {
              return { user: user.user, team: groupName };
            })
        : [];
    return clientService.general(kmApi.userApi.updUserOnGroup, undefined, { list: params, name: groupName }).then(res => {
      if (res.code === Constants.CODE.SUCCESS) {
        message.success(res.message);
        return true;
      } else {
        message.error(res.message);
        return false;
      }
    });
  };
  const add = (formInfo: any, upd?: boolean): Promise<boolean> => {
    if (upd) {
      return clientService.general(kmApi.userApi.updGroup, undefined, formInfo).then(res => {
        if (res.code === Constants.CODE.SUCCESS) {
          message.success(res.message);
        } else {
          message.error(res.message);
        }
        return res.code === Constants.CODE.SUCCESS;
      });
    } else {
      return clientService.general(kmApi.userApi.addGroup, undefined, formInfo).then(res => {
        if (res.code === Constants.CODE.SUCCESS) {
          message.success(res.message);
        } else {
          message.error(res.message);
        }
        return res.code === Constants.CODE.SUCCESS;
      });
    }
  };
  return { list, listOnGroup, updUserOnGroup, del, add };
};
