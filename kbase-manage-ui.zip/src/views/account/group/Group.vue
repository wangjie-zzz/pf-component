<template>
  <div class="km-flex km-flex-column km-bgwhite km-p-15">
    <div class="km-text-right km-pt-10">
      <el-button size="mini" icon="el-icon-refresh" @click="getGroupList" />
      <el-button size="mini" @click="deleteGroup">删除选中组</el-button>
      <el-button size="mini" type="primary" @click="addGroupClick">添加新的组</el-button>
    </div>
    <el-table
      class="km-mt-10"
      :data="groupList"
      :config="tableConfig"
      @selection-change="
        data => {
          ckGroupList = data;
        }
      "
    >
      <el-table-column label="操作" fixed="right" width="80">
        <template #default="scope">
          <el-tooltip effect="light" placement="left" trigger="hover">
            <i class="km-fs-18 el-icon-menu el-button&#45;&#45;text"></i>
            <template #content>
              <div class="km-flex km-flex-column km-flex-0">
                <el-button @click="handleClick(scope.row, 'edit')" type="text" size="mini">修改</el-button>
                <el-button @click="handleClick(scope.row, 'addUser')" type="text" size="mini">用户管理</el-button>
                <!--<el-button @click="handleClick(scope.row, 'addUser')" type="text" size="mini">添加用户</el-button>
                <el-button @click="handleClick(scope.row, 'delUser')" type="text" size="mini">删除用户</el-button>-->
                <el-button type="text" size="mini" @click="handleClick(scope.row, 'ipControl')">ip访问控制</el-button>
                <el-button type="text" size="mini" @click="handleClick(scope.row, 'dataGrant')">数据访问授权</el-button>
              </div>
            </template>
          </el-tooltip>
        </template>
      </el-table-column>
    </el-table>
    <el-dialog title="创建用户组" v-model="dialogVisible">
      <div class="km-flex km-ai-center km-mr-20">
        <el-form ref="groupForm" :config="formConfig" :model="formInfo" :colCount="1"></el-form>
      </div>
      <template #footer>
        <span>
          <el-button @click="dialogVisible = false">取消</el-button>
          <el-button type="primary" @click="addGroup">确定</el-button>
          <el-button type="primary">帮助</el-button>
        </span>
      </template>
    </el-dialog>
    <el-dialog title="用户管理" v-model="dialogVisible0">
      <el-transfer
        v-model="hasUsers"
        :titles="['组外用户', '组内用户']"
        :format="{
          noChecked: '${total}',
          hasChecked: '${checked}/${total}'
        }"
        :data="allUsers"
      >
        <!--@change="userChange"-->
        <template #default="{option}">
          <span>{{ option.user }}</span>
        </template>
      </el-transfer>
      <template #footer>
        <span>
          <el-button @click="dialogVisible0 = false">取消</el-button>
          <el-button type="primary" @click="updUser">确定</el-button>
          <el-button type="primary">帮助</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script lang="ts">
import { defineComponent, reactive, Ref, ref } from "vue";
import { userGroupField } from "@/constants/data/table-data";
import { useGroup } from "@/views/account/group/group";
import { useNotice } from "@/components/element-plus/notice";
import { toFormValue, userGroupForm } from "@/constants/data/form-data";

export default defineComponent({
  name: "Group",
  setup() {
    const tableConfig = userGroupField().checkbox();
    const groupList: Ref<any[]> = ref([]);
    const ckGroupList: Ref<any[]> = ref([]);

    const dialogVisible = ref(false);
    const dialogVisible0 = ref(false);
    const formConfig = reactive(userGroupForm());
    const formInfo = reactive(toFormValue(formConfig));
    const groupForm = ref(null);
    const allUsers: any[] = [];
    const hasUsers: Ref<any[]> = ref([]);
    const team: Ref<string> = ref("");
    const { message } = useNotice();

    const { list, del, listOnGroup, updUserOnGroup, add } = useGroup();
    const getGroupList = () => {
      list().then(res => {
        groupList.value = res;
      });
    };
    getGroupList();
    const deleteGroup = () => {
      del(ckGroupList.value).then(res => {
        if (res) {
          getGroupList();
        }
      });
    };
    const addGroupClick = () => {
      dialogVisible.value = true;
      formConfig.setDisable("team");
    };
    const addGroup = () => {
      (groupForm.value as any).validate((val: boolean) => {
        if (val) {
          if (!formConfig.getDisable("team")) {
            if (groupList.value.findIndex(e => e.team === formInfo.team) > -1) {
              message.error("该组名已存在");
              return;
            }
            add(formInfo).then(res => {
              if (res) {
                dialogVisible.value = false;
                getGroupList();
              }
            });
          } else {
            add(formInfo, true).then(res => {
              if (res) {
                dialogVisible.value = false;
                getGroupList();
              }
            });
          }
        }
      });
    };
    const updUser = () => {
      const userList = hasUsers.value.map(idx => {
        if (!isNaN(idx) && idx > -1) {
          return allUsers[idx];
        }
      });
      updUserOnGroup(userList, team.value).then(res => {
        if (res) {
          dialogVisible0.value = false;
        }
      });
    };
    const handleClick = (data: any, oper: string) => {
      switch (oper) {
        case "edit":
          dialogVisible.value = true;
          formConfig.setDisable("team", true);
          Object.assign(formInfo, data);
          break;
        case "addUser":
          team.value = data.team;
          listOnGroup(allUsers, team.value).then(res => {
            hasUsers.value = res;
            dialogVisible0.value = true;
          });
          break;
        case "delUser":
          message.error("待完善");
          break;
        default:
          message.error("待完善");
      }
    };
    return {
      tableConfig,
      groupList,
      ckGroupList,
      getGroupList,
      handleClick,
      deleteGroup,
      addGroup,
      addGroupClick,
      updUser,
      formConfig,
      groupForm,
      formInfo,
      dialogVisible,
      dialogVisible0,
      allUsers,
      hasUsers
    };
  }
});
</script>
<style scoped lang="scss">
.#{$prefix} {
}
</style>
