<template>
  <div>
    <el-button-group style="margin-bottom: 10px">
      <el-button @click="dialogVisible = true">创建词典</el-button>
      <el-button>引入词典</el-button>
    </el-button-group>

    <el-table :data="records.filter(data => !search || data.TABLENAME.toLowerCase().includes(search.toLowerCase()))" style="width: 100%">
      <el-table-column label="词典名称" prop="TABLENAME"> </el-table-column>
      <el-table-column label="词典路径" prop="TABLEPATH"> </el-table-column>
      <el-table-column align="right">
        <template #header>
          <el-input v-model="search" size="mini" placeholder="输入关键字搜索" />
        </template>
        <template #default="scope">
          <el-button size="mini" @click="handleEdit(scope.$index, scope.row)">更新</el-button>
          <el-button size="mini" type="danger" @click="handleDelete(scope.$index, scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog title="收货地址" v-model="dialogFormVisible">
      <el-form :model="form" size="mini" label-width="110px" label-position="left">
        <el-form-item label="活动名称">
          <el-input v-model="form.name" autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="活动区域">
          <el-select v-model="form.region" placeholder="请选择活动区域">
            <el-option label="区域一" value="shanghai"></el-option>
            <el-option label="区域二" value="beijing"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script lang="ts">
/* eslint-disable */
import { defineComponent, ref } from "vue";

import { clientService } from "@/services/client-service";
import { kmApi } from "@/constants/api/km-api";
import { useNotice } from "@/components/element-plus/notice";
import { Constants } from "@/constants/constants";

export default defineComponent({
  name: "SortDict",
  data() {
    return {
      form: {
        name: '',
        region: '',
        date1: '',
        date2: '',
        delivery: false,
        type: [],
        resource: '',
        desc: ''
      },
      sorttypeOptions: [{
        "label": "拼音",
        "value": "SPELL"
      }, {
        "label": "笔画",
        "value": 2
      }, {
        "label": "内码",
        "value": 3
      }],
    };
  },
  methods: {
    onOpen() {},
    onClose() {
    },
    close() {
      this.$emit('update:visible', false)
    },
    handelConfirm() {

    },
  },
  setup() {
    const { message } = useNotice();
    const records = ref([]);
    const search = ref('');
    const form = ref({
      path: '',
      checked: true,
      ext: 'sysdict'
    });
    const dialogFormVisible = ref(false);
    const props = ref({
      label: 'szName',
      // isLeaf: function(data) {
      //   return data.bIsFile == 1;
      // },
      isLeaf: (data: any) => data.bIsFile == 1
    });
    const rootDir = ref([]);
    const selectedPath = ref([]);
    const node_r = ref();
    const resovle_r = ref();

    const loadData = () => {
      clientService
          .general<any>(kmApi.sysManageApi.GetDictList, undefined)
          .then(function(res) {
            if (res.code != Constants.CODE.SUCCESS) {
              message.error(res.message);
            } else {
              records.value = res.data.records;
            }
          });
    }
    loadData();

    const loadRootDir = () => {
      clientService
          .general<any>(kmApi.sysManageApi.FS, undefined)
          .then(function(res) {
            if (res.code != Constants.CODE.SUCCESS) {
              message.error(res.message);
            } else {
              rootDir.value = res.data;
            }
          });
    }

    return {
      records,
      search,
      form,
      dialogFormVisible,
      props,
      rootDir,
      selectedPath,


      handleEdit(index: any, row: any) {
        clientService
            .general<any>(kmApi.sysManageApi.DictRefresh, {name: row.TABLENAME})
            .then(function(res) {
              if (res.code != Constants.CODE.SUCCESS) {
                message.error(res.message);
              } else {
                loadData();
              }
            });
      },
      handleDelete(index: any, row: any) {
        clientService
            .general<any>(kmApi.sysManageApi.DictDel, {name: row.TABLENAME})
            .then(function(res) {
              if (res.code != Constants.CODE.SUCCESS) {
                message.error(res.message);
              } else {
                loadData();
              }
            });
      }
    };
  }
});
</script>

<style scoped></style>
