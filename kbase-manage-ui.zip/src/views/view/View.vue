<template>
  <div>view info!!!</div>
</template>

<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({
  name: "View"
});
</script>

<style scoped></style>
