<template>
  <div class="km-task-queue">
    <h1>task-queue info!!!</h1>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from "vue";
import { useRoute } from "vue-router";

export default defineComponent({
  name: "TaskQueue",
  setup() {
    const router = useRoute();
    console.log(router.params);
    const isCollapse = ref(false);
    return { isCollapse };
  }
});
</script>
<style scoped lang="scss">
.#{$prefix} {
  &-task-queue {
  }
}
</style>
