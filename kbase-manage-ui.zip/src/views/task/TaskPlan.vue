<template>
  <div class="km-task-plan">
    <h1>task-plan info!!!</h1>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from "vue";
import { useRoute } from "vue-router";

export default defineComponent({
  name: "TaskPlan",
  setup() {
    const router = useRoute();
    console.log(router.params);
    const isCollapse = ref(false);
    return { isCollapse };
  }
});
</script>
<style scoped lang="scss">
.#{$prefix} {
  &-task-plan {
  }
}
</style>
