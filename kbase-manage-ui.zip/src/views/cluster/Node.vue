<template>
  <div class="km-node">
    <h1>node info!!!</h1>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from "vue";
import { useRoute } from "vue-router";

export default defineComponent({
  name: "Node",
  setup() {
    const router = useRoute();
    console.log(router.params);
    const isCollapse = ref(false);
    return { isCollapse };
  }
});
</script>
<style scoped lang="scss">
.#{$prefix} {
  &-node {
  }
}
</style>
