<template>
  <div class="km-params">
    <div class="km-text-right km-pt-15 km-mr-50">
      <el-button v-if="systemParamConfig.disabled" @click="edit" type="text">编辑</el-button>
      <el-button v-if="!systemParamConfig.disabled" @click="cancelSave" type="text">取消</el-button>
      <el-button v-if="!systemParamConfig.disabled" @click="confirmSave" type="text">保存</el-button>
    </div>
    <div class="km-mt-15">
      <el-form ref="systemParamForm" :config="systemParamConfig" :model="systemParamInfo"> </el-form>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, reactive, Ref, ref } from "vue";
import { systemParam, toFormValue } from "@/constants/data/form-data";
import { clientService } from "@/services/client-service";
import { kmApi } from "@/constants/api/km-api";
import { useNotice } from "@/components/element-plus/notice";
import { Constants } from "@/constants/constants";

export default defineComponent({
  name: "Params",
  setup() {
    const systemParamConfig = reactive(systemParam());
    systemParamConfig.setFormEdit(true);
    const { message } = useNotice();
    const systemParamForm = ref(null);
    const systemParamInfo: Ref<any> = ref(toFormValue(systemParamConfig));
    let systemParamInfoBak = "{}";
    const select = () => {
      clientService.general(kmApi.systemInfoApi.param).then(res => {
        if (res.code === Constants.CODE.SUCCESS) {
          systemParamInfo.value = res.data;
        } else {
          message.error(res.message);
        }
      });
    };
    select();
    const edit = () => {
      systemParamInfoBak = JSON.stringify(systemParamInfo.value);
      systemParamConfig.setFormEdit();
      systemParamConfig.setAllDisable(true);
      systemParamConfig.setDisable("autoCloseTime");
      systemParamConfig.setDisable("timeout");
      systemParamConfig.setDisable("qps");
    };
    const cancelSave = () => {
      systemParamInfo.value = JSON.parse(systemParamInfoBak);
      systemParamConfig.setFormEdit(true);
    };
    const confirmSave = () => {
      clientService.general(kmApi.systemInfoApi.paramUpd, undefined, systemParamInfo.value).then(res => {
        if (res.code === Constants.CODE.SUCCESS) {
          systemParamConfig.setFormEdit(true);
        } else {
          message.error(res.message);
          cancelSave();
        }
      });
    };
    return {
      systemParamForm,
      systemParamInfo,
      systemParamConfig,
      edit,
      cancelSave,
      confirmSave
    };
  }
});
</script>
<style scoped lang="scss">
.#{$prefix} {
  &-params {
    background: white;
  }
}
</style>
