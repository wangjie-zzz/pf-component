<template>
  <div class="km-login">
    <div class="km-flex km-jc-center km-mb-30">
      <img class="km-vertical-middle" src="@/assets/images/logo.gif" />
      <span class="km-fs-20 km-lh-50 km-ml-30 km-nowrap">webx-manager</span>
    </div>
    <div class="km-login-form">
      <el-form ref="loginForm" @keyup.enter="gologin" :size="'medium'" :config="loginConfig" :model="loginInfo" :col-count="1"> </el-form>
      <div class="km-login-btn km-text-right">
        <el-checkbox v-model="checked">自动登录</el-checkbox>
        <el-button class="km-w-100 km-mt-10" type="primary" @click="gologin">登录</el-button>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from "vue";
import { useRouter } from "vue-router";
import { authService } from "@/services/auth-service";
import { login, toFormValue } from "@/constants/data/form-data";
import { useNotice } from "@/components/element-plus/notice";
import { clientService } from "@/services/client-service";
import { kmApi } from "@/constants/api/km-api";
import { JSEncrypt } from "jsencrypt";
import { Constants } from "@/constants/constants";

export default defineComponent({
  name: "Login",
  setup() {
    const router = useRouter();
    const loginConfig = login();
    const loginForm = ref(null);
    const checked = ref(false);
    const loginInfo: any = toFormValue(loginConfig);
    return {
      loginConfig,
      loginInfo,
      loginForm,
      checked,
      gologin() {
        (loginForm.value as any).validate((val: boolean) => {
          if (val) {
            clientService.general(kmApi.userApi.getPuk).then(res => {
              if (res.code === Constants.CODE.SUCCESS) {
                const encrypt = new JSEncrypt({});
                encrypt.setPublicKey(res.data as any);
                const rsaStr = encrypt.encrypt(JSON.stringify(loginInfo));
                if (rsaStr) {
                  authService.login(rsaStr).then((res: boolean) => {
                    console.log("login:", res);
                    if (res) {
                      router.push({ path: "/main/database" });
                    }
                  });
                }
              } else {
                useNotice().message.error(res.message);
              }
            });
          }
        });
      }
    };
  }
});
</script>

<style scoped lang="scss">
.#{$prefix} {
  &-login {
    margin: 5% 30%;
    text-align: center;
    &-form {
      min-width: 400px;
      max-width: 500px;
      margin: 0 auto;
    }
    &-btn {
      width: calc(100% - 145px);
      margin-left: 80px;
    }
  }
}
</style>
