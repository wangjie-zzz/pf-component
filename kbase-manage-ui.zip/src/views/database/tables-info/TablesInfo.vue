<template>
  <!--数据表信息-->
  <div class="km-p-15">
    <div class="km-flex">
      <div class="km-flex">
        <el-input class="km-w-50 km-mr-15" placeholder="请输入表名" v-model="tableName" />
        <el-button size="mini" type="primary" @click="pageChange(undefined)">查询</el-button>
      </div>
      <div class="km-flex-1 km-text-right">
        <el-button size="mini" type="primary" @click="addTable">创建表</el-button>
        <el-button size="mini" @click="delTable">删除表</el-button>
        <!--      <el-button size="mini" type="primary">生成表结构脚本(功能同生成ksql脚本)</el-button>-->
        <el-button size="mini" type="primary" @click="exportTrie">生成trie文件</el-button>
      </div>
    </div>
    <el-table class="km-mt-10" :data="tableData" :config="dbs" :recordTotal="recordTotal" border @page-change="pageChange">
      <el-table-column label="操作" fixed="right" width="80">
        <template #default="scope">
          <el-tooltip effect="light" placement="left" trigger="hover">
            <i class="km-fs-18 el-icon-menu el-button&#45;&#45;text"></i>
            <template #content>
              <div class="km-flex km-flex-column km-flex-0">
                <el-button @click="handleClick(scope.row)" type="text" size="mini">属性</el-button>
                <el-button @click="handleClick(scope.row)" type="text" size="mini">清空</el-button>
                <el-button @click="handleClick(scope.row)" type="text" size="mini">打开</el-button>
                <!--                <el-button @click="handleClick(scope.row)" type="text" size="mini">重命名 移至点击表节点后</el-button>-->
                <!--                <el-button type="text" size="mini">修改表结构 移至点击表节点后</el-button>-->
                <!--                <el-button type="text" size="mini">修改表空间（存储空间/索引空间） 移至点击表节点后</el-button>-->
              </div>
            </template>
          </el-tooltip>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script lang="ts">
import { defineComponent, reactive, inject, ref, watch } from "vue";
import { databaseService } from "@/views/database/database-service";
import { database } from "@/constants/data/table-data";
import { Database } from "@/model/Database";
import { useNotice } from "@/components/element-plus/notice";

export default defineComponent({
  name: "TablesInfo",
  setup() {
    const dbs = reactive(database().checkbox());
    const recordTotal = ref(0);
    const tableName = ref("");
    const tableData: any = ref([]);
    const pageInfo = reactive({ pageSize: 10, pageNum: 1 });
    const { message } = useNotice();

    const treeData: Database[] = inject("treeData") || [];
    const dbName: any = inject("dbName");
    const handleClick = (data: any) => {
      message.warning("待完善");
      console.log(data);
    };
    const pageChange = (val?: any) => {
      if (!dbName.value) return;
      if (val) {
        pageInfo.pageSize = val.pageSize;
        pageInfo.pageNum = val.pageNum;
      }
      const params: any = { dbName: dbName.value, ...pageInfo };
      if (tableName.value) params.tableName = tableName.value;
      databaseService.getTables(params).then(res => {
        const db = treeData.find((db: Database) => db.label === dbName.value);
        if (db) {
          tableData.value = res.records;
          recordTotal.value = res.recordTotal;
        }
      });
    };
    watch(
      dbName,
      () => {
        pageChange();
      },
      { immediate: true }
    );
    const exportTrie = () => {
      message.error("待完善");
    };
    const addTable = () => {
      message.error("待完善");
    };
    const delTable = () => {
      message.error("待完善");
    };
    return {
      tableName,
      tableData,
      handleClick,
      recordTotal,
      dbs,
      pageChange,
      exportTrie,
      addTable,
      delTable
    };
  }
});
</script>
