<template>
  <el-table class="km-mt-10" :data="storeSpaceTableData" :config="storeSpaceTableConfig"> </el-table>
</template>

<script lang="ts">
import { defineComponent, inject, ref, Ref, watch } from "vue";
import { indexSpace, storeSpace } from "@/constants/data/table-data";
import { databaseService } from "@/views/database/database-service";

export default defineComponent({
  name: "StoreSpace",
  setup() {
    const tableName: any = inject("tableName") || {};
    const storeSpaceTableConfig = storeSpace().checkbox();
    const storeSpaceTableData: Ref<any[]> = ref([]);
    const select = () => {
      databaseService.getStoreSpace(tableName.value).then(res => {
        storeSpaceTableData.value = res;
      });
    };
    watch(
      tableName,
      () => {
        select();
      },
      { immediate: true }
    );
    return {
      storeSpaceTableConfig,
      storeSpaceTableData
    };
  }
});
</script>

<style lang="scss" scoped></style>
