<template>
  <el-table class="km-mt-10" :data="indexSpaceTableData" :config="indexSpaceTableConfig"> </el-table>
</template>

<script lang="ts">
import { defineComponent, inject, ref, Ref, watch } from "vue";
import { indexSpace } from "@/constants/data/table-data";
import { databaseService } from "@/views/database/database-service";

export default defineComponent({
  name: "IndexSpace",
  setup() {
    const tableName: any = inject("tableName") || {};
    const indexSpaceTableConfig = indexSpace().checkbox();
    const indexSpaceTableData: Ref<any[]> = ref([]);
    const select = () => {
      databaseService.getIndexSpace(tableName.value).then(res => {
        indexSpaceTableData.value = res;
      });
    };
    watch(
      tableName,
      () => {
        select();
      },
      { immediate: true }
    );
    return {
      indexSpaceTableConfig,
      indexSpaceTableData
    };
  }
});
</script>

<style lang="scss" scoped></style>
