<template>
  <div class="km-flex km-p-5">
    <div class="km-flex">
      <el-input class="km-w-50 km-mr-15" placeholder="请输入列名" v-model="fieldName" />
    </div>
    <div class="km-flex-1 km-text-right">
      <el-button @click="addField" type="primary">添加</el-button>
      <el-button @click="delField">删除</el-button>
      <el-button @click="importField">引入表结构</el-button>
      <el-button @click="importFile">文件导入</el-button>
      <el-button @click="exportFile">文件导出</el-button>
    </div>
  </div>
  <div class="km-mt-15">
    <el-table class="km-mt-10" :data="filterField" :config="tableConfig">
      <el-table-column label="操作" fixed="right" width="80">
        <template #default="scope">
          <el-button @click="updField(scope.row)" type="text" size="mini">修改</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script lang="ts">
import { computed, defineComponent, ref, toRef, toRefs } from "vue";
import { dataTableField } from "@/constants/data/table-data";
import { useNotice } from "@/components/element-plus/notice";

export default defineComponent({
  name: "TableField",
  props: {
    baseInfo: {
      type: Object,
      default: () => {
        return {};
      }
    }
  },
  setup(props) {
    const { baseInfo } = toRefs(props);
    const fieldName = ref("");

    const filterField = computed(() => {
      if (baseInfo.value.fieldList && baseInfo.value.fieldList.length) {
        const fields = baseInfo.value.fieldList.filter((f: any) => !fieldName.value || (f.name && f.name.indexOf(fieldName.value) > -1));
        return fields;
      }
      return [];
    });
    const tableConfig = dataTableField().checkbox();

    const { message } = useNotice();
    const addField = () => {
      message.error("待完善");
    };
    const delField = () => {
      message.error("待完善");
    };
    const updField = (row: any) => {
      message.error("待完善");
    };
    const importField = () => {
      message.error("待完善");
    };
    const importFile = () => {
      message.error("待完善");
    };
    const exportFile = () => {
      message.error("待完善");
    };
    return {
      fieldName,
      filterField,
      tableConfig,
      addField,
      delField,
      updField,
      importField,
      importFile,
      exportFile
    };
  }
});
</script>

<style lang="scss" scoped></style>
