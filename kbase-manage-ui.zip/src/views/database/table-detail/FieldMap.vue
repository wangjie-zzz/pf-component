<template>
  <div class="km-flex km-p-5">
    <div class="km-flex-1 km-text-left">
      <el-button size="mini" icon="el-icon-refresh" @click="refresh" />
      <el-button size="mini" @click="create" type="primary">创建</el-button>
      <el-button size="mini" @click="del">删除</el-button>
    </div>
  </div>
  <div class="km-mt-15">
    <el-table class="km-mt-10" :data="fieldMapTableData" :config="fieldMapTableConfig"> </el-table>
  </div>
  <el-dialog title="创建映射字段" v-model="dialogVisible">
    <div class="km-flex km-ai-center km-mr-20">
      <el-form ref="fieldMapForm" :config="formConfig" :model="formInfo" :colCount="1"></el-form>
    </div>
    <template #footer>
      <span>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="confirmCreate">确定</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script lang="ts">
import { defineComponent, inject, reactive, ref, Ref, toRefs, watch } from "vue";
import { fieldMapTable } from "@/constants/data/table-data";
import { databaseService } from "@/views/database/database-service";
import { useNotice } from "@/components/element-plus/notice";
import { fieldMap, toFormValue } from "@/constants/data/form-data";

export default defineComponent({
  name: "FieldMap",
  props: {
    baseInfo: {
      type: Object,
      default: () => {
        return {};
      }
    }
  },
  setup(props) {
    const { message } = useNotice();
    const { baseInfo } = toRefs(props);
    const tableName: any = inject("tableName") || {};
    const fieldMapTableConfig = fieldMapTable().checkbox();
    const fieldMapTableData: Ref<any[]> = ref([]);
    const dialogVisible = ref(false);
    const formConfig = reactive(fieldMap());
    const formInfo = reactive(toFormValue(formConfig));
    const fieldMapForm = ref(null);
    const transFieldMap = () => {
      if (fieldMapTableData.value && fieldMapTableData.value.length && baseInfo.value.fieldList && baseInfo.value.fieldList.length) {
        console.log(baseInfo.value.fieldList, fieldMapTableData);
        fieldMapTableData.value.forEach(f => {
          if (baseInfo.value.fieldList.length > f.srcNum) f.srcNum = baseInfo.value.fieldList[f.srcNum].name;
          if (baseInfo.value.fieldList.length > f.mapNum) f.mapNum = baseInfo.value.fieldList[f.mapNum].name;
        });
      }
    };
    const select = () => {
      databaseService.getFieldMap(tableName.value).then(res => {
        fieldMapTableData.value = res;
        // transFieldMap();
      });
    };
    watch(baseInfo, () => {
      const ops = baseInfo.value.fieldList?.map((f: any) => {
        return { key: f.name, value: f.name };
      });
      formConfig.setOptions("srcNum", ops);
      formConfig.setOptions("mapNum", ops);
      transFieldMap();
    });
    watch(
      tableName,
      () => {
        select();
      },
      { immediate: true }
    );
    const refresh = () => {
      select();
    };
    const create = () => {
      dialogVisible.value = true;
    };
    const confirmCreate = () => {
      message.error("待完善");
      dialogVisible.value = false;
    };
    const del = () => {
      message.error("待完善");
    };
    return {
      refresh,
      create,
      confirmCreate,
      del,
      dialogVisible,
      formConfig,
      formInfo,
      fieldMapForm,
      fieldMapTableConfig,
      fieldMapTableData
    };
  }
});
</script>

<style lang="scss" scoped></style>
