<template>
  <div class="km-flex km-p-5">
    <div class="km-flex-1 km-text-left">
      <el-button size="mini" icon="el-icon-refresh" @click="refresh" />
      <el-button size="mini" @click="dialogVisible = true" type="primary">创建排序索引</el-button>
      <el-button size="mini" @click="clear">清除排序索引文件数据</el-button>
      <el-button size="mini" @click="del">删除排序索引文件</el-button>
      <el-button size="mini" @click="sync">同步并行表的排序索引</el-button>
    </div>
  </div>
  <div class="km-mt-15">
    <el-table class="km-mt-10" :data="sortIndexTableData" :config="sortIndexTableConfig"> </el-table>
  </div>
  <el-dialog title="创建排序索引" v-model="dialogVisible">
    <div class="km-flex km-ai-center km-mr-20">
      <el-form ref="sortIndexForm" :config="formConfig" :model="formInfo" :colCount="1"></el-form>
    </div>
    <template #footer>
      <span>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="create">确定</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script lang="ts">
import { defineComponent, inject, reactive, ref, Ref, toRefs, watch } from "vue";
import { databaseService } from "@/views/database/database-service";
import { useNotice } from "@/components/element-plus/notice";
import { toFormValue, sortIndex } from "@/constants/data/form-data";
import { sortIndexTable } from "@/constants/data/table-data";

export default defineComponent({
  name: "SortIndex",
  props: {
    baseInfo: {
      type: Object,
      default: () => {
        return {};
      }
    }
  },
  setup(props) {
    const tableName: any = inject("tableName") || {};
    const { message } = useNotice();
    const { baseInfo } = toRefs(props);
    const dialogVisible = ref(false);
    const formConfig = reactive(sortIndex());
    const formInfo = reactive(toFormValue(formConfig));
    const sortIndexForm = ref(null);
    const sortIndexTableConfig = sortIndexTable().checkbox();
    const sortIndexTableData: Ref<any[]> = ref([]);
    const select = () => {
      databaseService.getSortIndex(tableName.value).then(res => {
        sortIndexTableData.value = res;
      });
    };
    watch(baseInfo, () => {
      formConfig.setOptions(
        "fields",
        baseInfo.value.fieldList?.map((f: any) => {
          return { key: f.name, value: f.name };
        })
      );
      /* TODO 排序词典待查询
      formConfig.setOptions(
      "dict",
      baseInfo.value.fieldList.map((f: any) => {
        return { key: f.name, value: f.name };
      })
    );*/
    });
    watch(
      tableName,
      () => {
        select();
      },
      { immediate: true }
    );
    const refresh = () => {
      select();
    };
    const create = () => {
      (sortIndexForm.value as any).validate((val: boolean) => {
        if (val) {
          message.error("待完善");
          dialogVisible.value = false;
        }
      });
    };
    const clear = () => {
      message.error("待完善");
    };
    const del = () => {
      message.error("待完善");
    };
    const sync = () => {
      message.error("待完善");
    };
    return {
      refresh,
      create,
      clear,
      del,
      sync,
      dialogVisible,
      formConfig,
      formInfo,
      sortIndexForm,
      sortIndexTableConfig,
      sortIndexTableData
    };
  }
});
</script>

<style lang="scss" scoped></style>
