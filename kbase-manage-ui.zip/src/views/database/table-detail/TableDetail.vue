<template>
  <!--数据表信息-->
  <div class="km-p-10">
    <el-tabs v-model="activeTab" @tab-click="handleClick">
      <el-tab-pane class="km-mt-20" label="基本信息" name="base">
        <div class="km-text-right km-mr-20">
          <el-button v-if="formConfig.disabled" @click="edit" type="text">编辑/重命名</el-button>
          <el-button v-if="!formConfig.disabled" @click="cancelSave" type="text">取消</el-button>
          <el-button v-if="!formConfig.disabled" @click="confirmSave" type="text">保存</el-button>
        </div>
        <div class="km-mt-15">
          <el-form :config="formConfig" :model="detailInfo"></el-form>
        </div>
      </el-tab-pane>
      <el-tab-pane class="km-mt-20" label="字段信息" name="field">
        <TableField :base-info="detailInfo"></TableField>
      </el-tab-pane>
      <el-tab-pane class="km-mt-20" label="映射字段" name="fieldMap">
        <FieldMap :base-info="detailInfo"></FieldMap>
      </el-tab-pane>
      <el-tab-pane v-if="detailInfo.type === 0" class="km-mt-20" label="存储空间" name="store">
        <StoreSpace></StoreSpace>
      </el-tab-pane>
      <el-tab-pane v-if="detailInfo.type === 0" class="km-mt-20" label="索引空间" name="index">
        <IndexSpace></IndexSpace>
      </el-tab-pane>
      <el-tab-pane class="km-mt-20" label="排序索引" name="sortIndex">
        <SortIndex :base-info="detailInfo"></SortIndex>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, reactive, inject, Ref, watch } from "vue";
import { databaseService } from "@/views/database/database-service";
import { dataTable, toFormValue } from "@/constants/data/form-data";
import { DataTable } from "@/model/Database";
import { useNotice } from "@/components/element-plus/notice";
import IndexSpace from "@/views/database/table-detail/IndexSpace.vue";
import TableField from "@/views/database/table-detail/TableField.vue";
import StoreSpace from "@/views/database/table-detail/StoreSpace.vue";
import SortIndex from "@/views/database/table-detail/SortIndex.vue";
import FieldMap from "@/views/database/table-detail/FieldMap.vue";
export default defineComponent({
  name: "TableDetail",
  components: { FieldMap, SortIndex, StoreSpace, TableField, IndexSpace },
  setup() {
    const formConfig = reactive(dataTable());
    formConfig.setFormEdit(true);
    const { message } = useNotice();
    const detailInfo: Ref<DataTable> = ref({} as any);
    const activeTab = ref("base");
    let detailInfoBak = "{}";
    const tableName: any = inject("tableName") || {};
    // const treeData: Database[] = inject("treeData") || [];
    const dbName: any = inject("dbName") || {};

    const select = () => {
      databaseService.getTableDetail(dbName.value, tableName.value).then(res => {
        if (res) {
          detailInfo.value = res;
        } else {
          detailInfo.value = toFormValue(formConfig);
        }
      });
    };
    watch(
      tableName,
      () => {
        select();
      },
      { immediate: true }
    );
    const handleClick = () => {};
    const edit = () => {
      detailInfoBak = JSON.stringify(detailInfo.value);
      formConfig.setFormEdit();
      formConfig.setAllDisable(true);
      formConfig.setDisable("label");
      formConfig.setDisable("aliasName");
    };
    const confirmSave = () => {
      detailInfo.value = JSON.parse(detailInfoBak);
      formConfig.setFormEdit(true);
      message.error("待完善");
    };
    const cancelSave = () => {
      detailInfo.value = JSON.parse(detailInfoBak);
      formConfig.setFormEdit(true);
    };
    return {
      activeTab,
      formConfig,
      detailInfo,
      handleClick,
      edit,
      confirmSave,
      cancelSave
    };
  }
});
</script>
