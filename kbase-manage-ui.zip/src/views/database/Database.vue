<template>
  <div class="km-min-h-100 km-flex">
    <div class="km-bgwhite km-p-15 km-mr-5">
      <div>
        <el-button size="mini" icon="el-icon-refresh" @click="setDbInfo"></el-button>
        <el-button size="mini" type="primary" @click="dialogVisible = true">创建数据库</el-button>
        <el-dialog title="创建数据库" v-model="dialogVisible">
          <div class="km-flex km-ai-center km-mr-20">
            <span class="km-nowrap">请输入数据库名称：</span>
            <el-input placeholder="请输入数据库名称" v-model="dbName" />
          </div>
          <template #footer>
            <span>
              <el-button type="primary" @click="createDb">确定</el-button>
            </span>
          </template>
        </el-dialog>
      </div>
      <el-tree :data="treeData" class="km-database-tree km-mt-10" @node-click="nodeClick" :default-expanded-keys="[currentNodeKey]" node-key="label" :highlight-current="true">
        <template #default="{ node, data }">
          <el-dropdown trigger="contextmenu" @command="cmd => contextmenuClick(cmd, node, data)">
            <span> {{ data.label }} </span>
            <template #dropdown>
              <el-dropdown-menu>
                <template v-for="cmd in cmdData" :key="cmd.cmd">
                  <el-dropdown-item v-if="data.children ? !cmd.table : cmd.table" :command="cmd.cmd">{{ cmd.text }}</el-dropdown-item>
                </template>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </template>
      </el-tree>
    </div>
    <div class="km-flex-1  km-bgwhite">
      <!--数据表详情-->
      <table-detail class="animate__animated animate__fadeIn" v-if="showDetail"></table-detail>
      <!--数据表信息-->
      <tables-info class="animate__animated animate__fadeIn" v-else></tables-info>
    </div>
  </div>
</template>

<script lang="ts">
import { computed, defineComponent, h, provide, reactive, ref } from "vue";
import { databaseService } from "@/views/database/database-service";
import TablesInfo from "@/views/database/tables-info/TablesInfo.vue";
import TableDetail from "@/views/database/table-detail/TableDetail.vue";
import { Database, DataTable } from "@/model/Database";
import { ElInput, ElMessageBox } from "element-plus";
import { useNotice } from "@/components/element-plus/notice";
export default defineComponent({
  name: "Database",
  components: { TablesInfo, TableDetail },
  setup() {
    const showDetail = ref(false);
    const currentNodeKey = ref("");
    const dbName = ref("");
    const dialogVisible = ref(false);
    const tableName = ref("");
    const treeData: Database[] = reactive([]);
    const cmdData = databaseService.cmdData();
    provide("treeData", treeData);
    provide("dbName", currentNodeKey);
    provide("tableName", tableName);
    const setDbInfo = () => {
      databaseService.getDbInfo().then(res => {
        if (res && res.length > 0) {
          treeData.splice(0, treeData.length);
          treeData.push(...res);
          // eslint-disable-next-line @typescript-eslint/no-use-before-define
          nodeClick(res[0]);
        }
      });
    };
    setDbInfo();
    const createDb = () => {
      const { message } = useNotice();
      if (!dbName.value) {
        message.error("请输入数据库名称");
        return;
      }
      if (treeData.findIndex(db => db.label === dbName.value) > -1) {
        message.error("该数据库已存在");
        return;
      }
      databaseService.createDb(dbName.value).then(res => {
        if (res) {
          dialogVisible.value = false;
        }
      });
    };
    const contextmenuClick = (cmd: string, node: any, data: Database) => {
      console.log(cmd, node, data);
      const { message } = useNotice();
      // 数据库下表刷新
      switch (cmd) {
        case "del":
          /*删除数据库*/
          databaseService.deleteDb(data.label).then(res => {
            if (res) {
              treeData.splice(
                treeData.findIndex(t => t.label === data.label),
                1
              );
            }
          });
          break;
        case "cp":
          /*备份数据库*/
          message.warning(`${cmd}待完善`);
          break;
        case "rev":
          /*恢复数据库*/
          message.warning(`${cmd}待完善`);
          break;
        case "rel":
          /*引入表*/
          message.warning(`${cmd}待完善`);
          break;
        case "link":
          /*连接外部表*/
          message.warning(`${cmd}待完善`);
          break;
        case "mvt":
          /*移动表*/
          message.warning(`${cmd}待完善`);
          break;
        case "syst":
          /*同步超表*/
          message.warning(`${cmd}待完善`);
          break;
        case "ikf":
          /*映射表字段*/
          message.warning(`${cmd}待完善`);
          break;
        case "gnsql":
          /*生成ksql脚本*/
          message.warning(`${cmd}待完善`);
          break;
        case "idxck":
          /*索引检查*/
          message.warning(`${cmd}待完善`);
          break;
        case "tk":
          /*任务（...）*/
          message.warning(`${cmd}待完善`);
          break;
        case "rl":
          /*数据访问授权*/
          message.warning(`${cmd}待完善`);
          break;
        case "ref":
          /*数据表刷新*/
          databaseService.getAllTables(data.label).then(res => {
            const db = treeData.find((db: Database) => db.label === data.label);
            if (db) db.children = res;
          });
          break;
        default:
          message.warning(`${cmd}待完善`);
          console.log("default");
      }
    };
    const nodeClick = (data: Database | DataTable, b?: any, c?: any) => {
      showDetail.value = Object.keys(data).findIndex(k => k === "children") === -1;
      if (showDetail.value) {
        // 点击表节点
        tableName.value = data.label;
        currentNodeKey.value = databaseService.findDbName(data.label, treeData);
      } else {
        // 点击数据库节点
        currentNodeKey.value = data.label;
        const db = treeData.find((db: Database) => db.label === data.label);
        if (db && !db.children?.length) {
          databaseService.getAllTables(data.label).then(res => {
            db.children = res;
          });
        }
      }
    };
    return {
      treeData,
      showDetail,
      currentNodeKey,
      tableName,
      dbName,
      dialogVisible,
      cmdData,
      contextmenuClick,
      nodeClick,
      setDbInfo,
      createDb
    };
  }
});
</script>

<style scoped lang="scss">
.#{$prefix} {
  &-database-tree {
    min-width: 190px;
    max-width: 190px;
  }
}
</style>
