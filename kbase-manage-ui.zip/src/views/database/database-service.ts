import { Database, DataTable } from "@/model/Database";
import { clientService } from "@/services/client-service";
import { kmApi } from "@/constants/api/km-api";
import { Constants } from "@/constants/constants";
import { useNotice } from "@/components/element-plus/notice";
import { Page } from "@/model/Page";

class DatabaseService {
  cmdData(): { cmd: string; text: string; table?: boolean }[] {
    return [
      { cmd: "del", text: "删除数据库" },
      { cmd: "cp", text: "备份数据库" },
      { cmd: "rev", text: "恢复数据库" },
      { cmd: "rel", text: "引入表" },
      { cmd: "link", text: "连接外部表" },
      { cmd: "ref", text: "刷新" },
      { cmd: "mvt", text: "移动表", table: true },
      { cmd: "syst", text: "同步超表", table: true },
      { cmd: "ikf", text: "映射表字段", table: true },
      { cmd: "gnsql", text: "生成ksql脚本", table: true },
      { cmd: "idxck", text: "索引检查", table: true },
      { cmd: "tk", text: "任务（...）", table: true },
      { cmd: "rl", text: "数据访问授权", table: true }
    ];
  }
  createDb(dbName: string): Promise<boolean> {
    const { message, loading } = useNotice();
    loading.open("创建中...");
    return clientService
      .general<string[]>(kmApi.dbManageApi.create, { dbName })
      .then(res => {
        loading.close();
        if (res.code === Constants.CODE.SUCCESS) {
          message.success(res.message);
          return true;
        } else {
          message.error(res.message);
          return false;
        }
      });
  }
  deleteDb(dbName: string): Promise<boolean> {
    const { message, loading } = useNotice();
    loading.open("删除中...");
    return clientService
      .general<string[]>(kmApi.dbManageApi.delete, { dbName })
      .then(res => {
        loading.close();
        if (res.code === Constants.CODE.SUCCESS) {
          message.success(res.message);
          return true;
        } else {
          message.error(res.message);
          return false;
        }
      });
  }
  getDbInfo(): Promise<Database[]> {
    const { message } = useNotice();
    return clientService.general<string[]>(kmApi.dbManageApi.list, undefined).then(res => {
      if (res.code === Constants.CODE.SUCCESS) {
        message.success(res.message);
        return res.data.map(db => {
          return {
            label: db,
            children: []
          };
        });
      } else {
        message.error(res.message);
        return [];
      }
    });
  }
  getTables(params: any): Promise<Page<any>> {
    const { loading, message } = useNotice();
    loading.open();
    return clientService.general<Page<any>>(kmApi.dbManageApi.tableListPage, params).then(res => {
      loading.close();
      if (res.code === Constants.CODE.SUCCESS) {
        return res.data;
      } else {
        message.error(res.message);
        return {} as any;
      }
    });
  }
  getAllTables(dbName: string): Promise<DataTable[]> {
    const { loading, message } = useNotice();
    loading.open();
    return clientService
      .general<any>(kmApi.dbManageApi.tableList, { dbName })
      .then(res => {
        loading.close();
        if (res.code === Constants.CODE.SUCCESS) {
          return res.data.map((tb: any) => {
            return {
              label: tb
            };
          });
        } else {
          message.error(res.message);
          return [];
        }
      });
  }
  getTableDetail(dbName: string, tableName: string): Promise<DataTable | undefined> {
    const { message } = useNotice();
    return clientService.general(kmApi.dbManageApi.tableDetail, { dbName, tableName }).then(res => {
      if (res.code === Constants.CODE.SUCCESS) {
        return res.data;
      } else {
        message.error(res.message);
        return undefined as any;
      }
    });
  }
  getIndexSpace(tableName: string): Promise<any[]> {
    const { message } = useNotice();
    return clientService
      .general<any[]>(kmApi.dbManageApi.indexSpace, { tableName })
      .then(res => {
        if (res.code === Constants.CODE.SUCCESS) {
          return res.data;
        } else {
          message.error(res.message);
          return [];
        }
      });
  }
  getStoreSpace(tableName: string): Promise<any[]> {
    const { message } = useNotice();
    return clientService
      .general<any[]>(kmApi.dbManageApi.storeSpace, { tableName })
      .then(res => {
        if (res.code === Constants.CODE.SUCCESS) {
          return res.data;
        } else {
          message.error(res.message);
          return [];
        }
      });
  }
  getSortIndex(tableName: string): Promise<any[]> {
    const { message } = useNotice();
    return clientService
      .general<any[]>(kmApi.dbManageApi.sortIndex, { tableName })
      .then(res => {
        if (res.code === Constants.CODE.SUCCESS) {
          return res.data;
        } else {
          message.error(res.message);
          return [];
        }
      });
  }
  getFieldMap(tableName: string): Promise<any[]> {
    const { message } = useNotice();
    return clientService
      .general<any[]>(kmApi.dbManageApi.fieldMap, { tableName })
      .then(res => {
        if (res.code === Constants.CODE.SUCCESS) {
          return res.data;
        } else {
          message.error(res.message);
          return [];
        }
      });
  }
  findDbName(tableName: string, dbInfo: Database[]): string {
    for (const database of dbInfo) {
      const idx = database.children?.findIndex(e => e.label === tableName);
      if (idx !== undefined && idx > -1) {
        return database.label;
      }
    }
    return "";
  }
}
export const databaseService = new DatabaseService();
