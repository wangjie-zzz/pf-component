<template>
  <div>expand info!!!</div>
</template>

<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({
  name: "Expand"
});
</script>

<style scoped></style>
