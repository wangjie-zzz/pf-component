export interface Database {
  label: string;
  children?: DataTable[];
}
export interface DataTable {
  label: string;
  own: string;
  ip: string;
  type: string;
  relName: string;
  relPk: string;
  ct: string;
  size: string;
  url: string;
  fieldList: any[];
}
