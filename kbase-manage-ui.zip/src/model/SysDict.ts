export interface SysDict {
  name: string;
  key: string;
  value: string;
  length?: string;
  flag?: string;
  type?: string;
}
