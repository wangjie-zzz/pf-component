export interface KmMenu {
  menuId: string;
  menuName: string;
  menuType: string;
  menuUrl: string;
  menuIcon?: string;
  children: Array<KmMenu>;
}
