export const task = [
  {
    path: "task/task-plan",
    name: "TaskPlan",
    component: () => import(/* webpackChunkName: "Task" */ "@/views/task/TaskPlan.vue")
  },
  {
    path: "task/task-queue",
    name: "TaskQueue",
    component: () => import(/* webpackChunkName: "Task" */ "@/views/task/TaskQueue.vue")
  }
];
