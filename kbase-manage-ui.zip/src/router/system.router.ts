export const system = [
  {
    path: "system/params",
    name: "Params",
    component: () => import(/* webpackChunkName: "System" */ "@/views/system/Params.vue")
  },
  {
    path: "system/logs",
    name: "Logs",
    component: () => import(/* webpackChunkName: "System" */ "@/views/system/Logs.vue")
  }
];
