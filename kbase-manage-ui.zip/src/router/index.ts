import { createRouter, createWebHistory, RouteRecordRaw } from "vue-router";
import { account } from "@/router/account.router";
import { cluster } from "@/router/cluster.router";
import { system } from "@/router/system.router";
import { task } from "@/router/task.router";
import { Constants } from "@/constants/constants";
import { authService } from "@/services/auth-service";
import { clientService } from "@/services/client-service";

const routes: Array<RouteRecordRaw> = [
  {
    path: "/",
    redirect: "/main/database"
  },
  {
    path: "/main",
    name: "Main",
    component: () => import(/* webpackChunkName: "Main" */ "@/views/Main.vue"),
    children: [
      {
        path: "database",
        name: "Database",
        component: () => import(/* webpackChunkName: "Main" */ "@/views/database/Database.vue")
      },
      {
        path: "view",
        name: "View",
        component: () => import(/* webpackChunkName: "Main" */ "@/views/view/View.vue")
      },
      {
        path: "expand",
        name: "Expand",
        component: () => import(/* webpackChunkName: "Main" */ "@/views/expand/Expand.vue")
      },
      {
        path: "dictionary",
        name: "Dictionary",
        component: () => import(/* webpackChunkName: "Main" */ "@/views/dictionary/Dictionary.vue")
      },
      {
        path: "fieldtype",
        name: "FieldType",
        component: () => import(/* webpackChunkName: "Main" */ "@/views/qbe/FieldType.vue")
      },
      {
        path: "indextype",
        name: "IndexType",
        component: () => import(/* webpackChunkName: "Main" */ "@/views/qbe/IndexType.vue")
      },
      {
        path: "help/register",
        name: "Register",
        component: () => import(/* webpackChunkName: "Main" */ "@/views/qbe/Register.vue")
      },
      {
        path: "test",
        name: "Test",
        component: () => import(/* webpackChunkName: "Main" */ "@/views/test/Test.vue")
      },
      ...account,
      ...cluster,
      ...system,
      ...task
    ]
  },
  {
    path: "/login",
    name: "Login",
    component: () => import(/* webpackChunkName: "Login" */ "@/views/login/Login.vue")
  },
  {
    path: "/:pathMatch(.*)*",
    component: () => import(/* webpackChunkName: "Main" */ "@/views/404/404.vue")
  }
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes: routes
});
router.beforeEach((to, from, next) => {
  console.log(to, from);
  if (authService.checkLogin() || Constants.PERMITALL.findIndex(path => path === to.fullPath) > -1) {
    next();
  } else if (clientService.autoLogin) {
    authService.login(Constants.DEFAULT_KBASE).then(res => {
      if (res) {
        next();
      } else {
        next("/login");
      }
    });
  } else {
    next("/login");
  }
});
export default router;
