export const cluster = [
  {
    path: "cluster/node",
    name: "Node",
    component: () => import(/* webpackChunkName: "Cluster" */ "@/views/cluster/Node.vue")
  },
  {
    path: "cluster/table",
    name: "Table",
    component: () => import(/* webpackChunkName: "Cluster" */ "@/views/cluster/Table.vue")
  }
];
