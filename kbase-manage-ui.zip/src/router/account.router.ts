export const account = [
  {
    path: "account/group",
    name: "Group",
    component: () => import(/* webpackChunkName: "Account" */ "@/views/account/group/Group.vue")
  },
  {
    path: "account/user",
    name: "User",
    component: () => import(/* webpackChunkName: "Account" */ "@/views/account/user/User.vue")
  },
  {
    path: "account/ol-user",
    name: "OlUser",
    component: () => import(/* webpackChunkName: "Account" */ "@/views/account/ol-user/OlUser.vue")
  }
];
